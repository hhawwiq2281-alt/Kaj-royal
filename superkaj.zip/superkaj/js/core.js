/* ============================================================
   سوپر کاج — هسته: ابزارها، ذخیره‌سازی، اسکین‌ها، صدا
   ============================================================ */
'use strict';

/* ---------- ثابت‌ها ---------- */
const TILE = 32;          // اندازه هر خانه زمین
const VIEW_W = 960;       // عرض بوم
const VIEW_H = 544;       // ارتفاع بوم
const ROWS = 17;          // تعداد ردیف‌های مرحله
const TOTAL_LEVELS = 30;
const CONES_PER_PICKUP = 8;   // هر کاج چند تیر می‌دهد
const MAX_HEARTS = 5;         // قلب در هر مرحله
/* ⚙️ حالت توسعه: فقط وقتی آدرس صفحه شامل ?debug=1 باشد فعال می‌شود (مثلاً index.html?debug=1).
   پیش‌فرض خاموش است. در حالت توسعه، قلب بی‌نهایت می‌شود. */
const DEBUG = (function () {
  try { return new URLSearchParams(window.location.search).get('debug') === '1'; }
  catch (e) { return false; }
})();
const CHEAT_INF_HEARTS = DEBUG;

/* ---------- ابزار ---------- */
const FA_DIGITS = '۰۱۲۳۴۵۶۷۸۹';
function faNum(n) { return String(Math.round(n)).replace(/[0-9]/g, d => FA_DIGITS[+d]); }
function clamp(v, a, b) { return v < a ? a : (v > b ? b : v); }
function lerp(a, b, t) { return a + (b - a) * t; }
function rndi(rng, a, b) { return a + Math.floor(rng() * (b - a + 1)); }

/* مولد اعداد شبه‌تصادفی با بذر (تا هر مرحله همیشه یکسان ساخته شود) */
function mulberry32(seed) {
  let a = seed | 0;
  return function () {
    a = (a + 0x6D2B79F5) | 0;
    let t = Math.imul(a ^ (a >>> 15), 1 | a);
    t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}

/* ---------- اسکین‌ها ----------
   قیمت‌ها: priceC = سکه، priceD = الماس (اسکین کلاسیک رایگان است) */
const SKINS = [
  {
    id: 'classic', name: 'کلاسیک ماریویی', desc: 'همان قهرمان همیشگی!',
    priceC: 0, priceD: 0,
    pal: { cap: '#e5352b', shirt: '#e5352b', overall: '#2a4bd7', skin: '#ffd1a3', shoe: '#6e3a14', acc: '#ffffff' }
  },
  {
    id: 'forest', name: 'قهرمان جنگل', desc: 'کاپ سبز، روح جنگل',
    priceC: 200, priceD: 0,
    pal: { cap: '#2fae4e', shirt: '#4ade80', overall: '#14532d', skin: '#ffd1a3', shoe: '#4a2c0f', acc: '#d9f99d' }
  },
  {
    id: 'ninja', name: 'نینجای شب', desc: 'سریع و بی‌صدا (ظاهری!)',
    priceC: 600, priceD: 0,
    pal: { cap: '#1f2937', shirt: '#374151', overall: '#111827', skin: '#e8b98a', shoe: '#0b0f19', acc: '#ef4444' }
  },
  {
    id: 'astro', name: 'فضانورد', desc: 'آماده پرواز به ستاره‌ها',
    priceC: 1500, priceD: 8,
    pal: { cap: '#f8fafc', shirt: '#f1f5f9', overall: '#cbd5e1', skin: '#ffd1a3', shoe: '#f97316', acc: '#38bdf8' }
  },
  {
    id: 'gold', name: 'شاه طلایی', desc: 'با تاج شاهانه! جواهر مجموعه',
    priceC: 3000, priceD: 0,
    pal: { cap: '#ffd23e', shirt: '#fbbf24', overall: '#b45309', skin: '#ffe0b8', shoe: '#78350f', acc: '#fff7cc' }
  },
  {
    id: 'gem', name: 'الماس‌بازی', desc: 'یخی و براق مثل الماس',
    priceC: 0, priceD: 25,
    pal: { cap: '#4de3e0', shirt: '#67e8f9', overall: '#0e7490', skin: '#ffe0c2', shoe: '#155e75', acc: '#ffffff' }
  },
  {
    id: 'armor', name: 'مرد زرهی', desc: 'زره فولادی: ۴ برخورد پشت‌سرهم بی‌آسیب + تنها قهرمانی که دشمن تیغ‌دار را با پرش له می‌کند!',
    priceC: 2500, priceD: 0,
    pal: { cap: '#9aa5b5', shirt: '#b7c0cf', overall: '#5b6578', skin: '#e8b98a', shoe: '#39415a', acc: '#dfe6f2' }
  },
  {
    id: 'demon', name: 'قهرمان شیطانی', desc: 'کلید J (موبایل: دکمه 🌊): موج شیطانی می‌فرستد و همه‌ی دشمن‌های اطراف می‌میرند — ۳ بار در هر مرحله!',
    priceC: 2000, priceD: 0,
    pal: { cap: '#6e1028', shirt: '#b03060', overall: '#3b0d26', skin: '#f2b9a0', shoe: '#2a0a1a', acc: '#ff5e8a' }
  }
];
function skinById(id) { return SKINS.find(s => s.id === id) || SKINS[0]; }

/* ---------- ذخیره‌سازی (localStorage) ---------- */
const Save = {
  KEY: 'superKaj_save_v1',
  data: { coins: 0, diamonds: 0, unlocked: 1, current: 1, completed: [], skin: 'classic', owned: ['classic'], sound: true, music: true, finished15: false, finished30: false },

  load() {
    try {
      const raw = localStorage.getItem(this.KEY);
      if (raw) {
        const d = JSON.parse(raw);
        this.data = Object.assign(this.data, d);
        if (!Array.isArray(this.data.completed)) this.data.completed = [];
        if (!Array.isArray(this.data.owned) || !this.data.owned.length) this.data.owned = ['classic'];
        /* اسکین انتخابی باید وجود داشته باشد و در مالکیت بازیکن باشد، وگرنه به کلاسیک برمی‌گردد
           (اسکین‌هایی که قبلاً در حالت تست رایگان گرفته شده‌اند در owned می‌مانند و دوباره پول نمی‌خواهند) */
        if (!SKINS.some(s => s.id === this.data.skin) || !this.data.owned.includes(this.data.skin)) this.data.skin = 'classic';
        this.data.unlocked = clamp(this.data.unlocked || 1, 1, TOTAL_LEVELS);
        this.data.current = clamp(this.data.current || 1, 1, this.data.unlocked);
        /* بازیکنانی که قبلاً ۱۵ مرحله را تمام کرده بودند → مراحل ۱۶ به بعد برایشان باز است */
        if (this.data.finished15 && TOTAL_LEVELS > 15) this.data.unlocked = Math.max(this.data.unlocked, 16);
      }
    } catch (e) { /* حالت خصوصی مرورگر و... */ }
  },
  persist() {
    try { localStorage.setItem(this.KEY, JSON.stringify(this.data)); } catch (e) { }
  },
  addCoins(n) { this.data.coins += n; this.persist(); },
  addDiamonds(n) { this.data.diamonds += n; this.persist(); },
  spend(c, d) {
    if (this.data.coins < c || this.data.diamonds < d) return false;
    this.data.coins -= c; this.data.diamonds -= d; this.persist(); return true;
  },
  ownSkin(id) { if (!this.data.owned.includes(id)) { this.data.owned.push(id); this.persist(); } },
  selectSkin(id) { this.data.skin = id; this.persist(); },
  startLevel(lvl) { this.data.current = lvl; this.persist(); },
  /* اتمام موفق مرحله → باز شدن مرحله بعد */
  completeLevel(lvl) {
    if (!this.data.completed.includes(lvl)) this.data.completed.push(lvl);
    if (lvl < TOTAL_LEVELS) this.data.unlocked = Math.max(this.data.unlocked, lvl + 1);
    if (lvl >= 15) this.data.finished15 = true;
    if (lvl >= TOTAL_LEVELS) this.data.finished30 = true;
    this.data.current = clamp(lvl + 1, 1, TOTAL_LEVELS);
    this.persist();
  },
  reset() {
    this.data = { coins: 0, diamonds: 0, unlocked: 1, current: 1, completed: [], skin: 'classic', owned: ['classic'], sound: true, music: true, finished15: false, finished30: false };
    this.persist();
  }
};

/* ---------- صدا (Web Audio) ---------- */
const AudioSys = {
  ctx: null, master: null,
  seqTimer: null, seqStep: 0,

  ensure() {
    if (!this.ctx) {
      try {
        this.ctx = new (window.AudioContext || window.webkitAudioContext)();
        this.master = this.ctx.createGain();
        this.master.gain.value = 0.5;
        this.master.connect(this.ctx.destination);
      } catch (e) { }
    }
    if (this.ctx && this.ctx.state === 'suspended') this.ctx.resume();
  },

  /* قطع/وصل کل خروجی صدا (هنگام مخفی شدن تب) */
  suspend() {
    if (this.ctx && this.ctx.state === 'running') { try { this.ctx.suspend(); } catch (e) { } }
  },
  unsuspend() {
    if (this.ctx && this.ctx.state === 'suspended') { try { this.ctx.resume(); } catch (e) { } }
  },

  /* یک نوت ساده با پوش صدا */
  tone(freq, dur, type, vol, slideTo, delay) {
    if (!this.ctx) return;
    const t0 = this.ctx.currentTime + (delay || 0);
    const osc = this.ctx.createOscillator();
    const g = this.ctx.createGain();
    osc.type = type || 'square';
    osc.frequency.setValueAtTime(freq, t0);
    if (slideTo) osc.frequency.linearRampToValueAtTime(slideTo, t0 + dur);
    g.gain.setValueAtTime(0.0001, t0);
    g.gain.linearRampToValueAtTime(vol || 0.08, t0 + 0.012);
    g.gain.exponentialRampToValueAtTime(0.0001, t0 + dur);
    osc.connect(g); g.connect(this.master);
    osc.start(t0); osc.stop(t0 + dur + 0.05);
  },

  sfx(name) {
    if (!Save.data.sound) return;
    this.ensure();
    if (!this.ctx) return;
    switch (name) {
      case 'jump': this.tone(300, 0.18, 'square', 0.06, 620); break;
      case 'coin': this.tone(988, 0.07, 'square', 0.05); this.tone(1319, 0.16, 'square', 0.05, 0, 0.07); break;
      case 'diamond': this.tone(660, 0.09, 'triangle', 0.07); this.tone(880, 0.09, 'triangle', 0.07, 0, 0.08); this.tone(1320, 0.2, 'triangle', 0.07, 0, 0.16); break;
      case 'cone': this.tone(520, 0.1, 'triangle', 0.08, 780); break;
      case 'shoot': this.tone(240, 0.12, 'sawtooth', 0.05, 90); break;
      case 'stomp': this.tone(280, 0.14, 'square', 0.07, 70); break;
      case 'hurt': this.tone(160, 0.25, 'sawtooth', 0.09, 60); break;
      case 'click': this.tone(700, 0.05, 'square', 0.04); break;
      case 'check': this.tone(523, 0.1, 'triangle', 0.07); this.tone(784, 0.18, 'triangle', 0.07, 0, 0.1); break;
      case 'heart': this.tone(660, 0.09, 'square', 0.06); this.tone(880, 0.09, 'square', 0.06, 0, 0.08); this.tone(1175, 0.2, 'square', 0.06, 0, 0.16); break;
      case 'shield': this.tone(392, 0.1, 'triangle', 0.07); this.tone(523, 0.1, 'triangle', 0.07, 0, 0.09); this.tone(784, 0.24, 'triangle', 0.07, 0, 0.18); break;
      case 'shieldbreak': this.tone(520, 0.2, 'sawtooth', 0.07, 130); this.tone(260, 0.18, 'square', 0.05, 80, 0.06); break;
      case 'win': [523, 659, 784, 1047].forEach((f, i) => this.tone(f, 0.16, 'square', 0.06, 0, i * 0.13)); break;
      case 'lose': [392, 330, 262, 196].forEach((f, i) => this.tone(f, 0.22, 'triangle', 0.07, 0, i * 0.18)); break;
      case 'unlock': [784, 988, 1175, 1568].forEach((f, i) => this.tone(f, 0.12, 'square', 0.05, 0, i * 0.09)); break;
      case 'empty': this.tone(180, 0.08, 'square', 0.04); break;
    }
  },

  /* موسیقی زمینه ۸-بیتی (حلقه ساده) */
  BASS: [110, 110, 131, 110, 147, 131, 110, 98, 110, 110, 131, 110, 165, 147, 131, 98],
  LEAD: [440, 0, 523, 0, 659, 587, 523, 0, 440, 0, 523, 659, 784, 0, 659, 523],

  startMusic() {
    if (!Save.data.music) return;
    this.stopMusic();
    this.ensure();
    if (!this.ctx) return;
    this.seqStep = 0;
    const stepMs = 200; // ۱۵۰ BPM تقریبی
    this.seqTimer = setInterval(() => {
      if (!Save.data.music || !Save.data.sound) return;
      const s = this.seqStep % 16;
      const b = this.BASS[s];
      if (b) this.tone(b, 0.16, 'triangle', 0.045);
      const l = this.LEAD[s];
      if (l) this.tone(l, 0.14, 'square', 0.022);
      if (s % 4 === 0) this.tone(70, 0.05, 'sine', 0.05); // ضرب
      this.seqStep++;
    }, stepMs);
  },
  stopMusic() { if (this.seqTimer) { clearInterval(this.seqTimer); this.seqTimer = null; } }
};
