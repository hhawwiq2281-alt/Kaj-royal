/* ============================================================
   سوپر کاج — رابط کاربری: منو، نقشه، فروشگاه، کنترل‌ها
   ============================================================ */
'use strict';

const UI = {
  $: id => document.getElementById(id),
  _hudCache: {},

  init() {
    /* --- دکمه‌های منو --- */
    this.$('btn-start').onclick = () => { this.click(); this.showMap(); };
    this.$('btn-continue').onclick = () => { this.click(); this.hideOverlays(); Game.startLevel(Save.data.current); this.showScreen('game'); };
    this.$('btn-shop').onclick = () => { this.click(); this.showShop(); };
    this.$('btn-help').onclick = () => { this.click(); this.showScreen('help'); };
    this.$('btn-sound').onclick = () => {
      Save.data.sound = !Save.data.sound;
      if (!Save.data.sound) AudioSys.stopMusic();
      else { AudioSys.ensure(); if (Game.state === 'play') AudioSys.startMusic(); }
      Save.persist(); this.refreshSoundBtn(); AudioSys.sfx('click');
    };

    /* --- ناوبری --- */
    this.$('map-back').onclick = () => { this.click(); this.showScreen('menu'); };
    this.$('shop-back').onclick = () => { this.click(); this.showScreen('menu'); };
    this.$('help-back').onclick = () => { this.click(); this.showScreen('menu'); };

    /* --- توقف --- */
    this.$('btn-pause').onclick = () => this.pause();
    this.$('btn-resume').onclick = () => this.resume();
    this.$('btn-restart').onclick = () => { this.click(); this.restartLevel(); };
    this.$('btn-quit').onclick = () => { this.click(); this.exitToMap(); };

    /* --- موج شیطانی (اسکین قهرمان شیطانی) — دکمه لمسی کوچک --- */
    this.$('tc-wave').onclick = () => { this.click(); Game.devilWave(); };

    /* --- پایان مرحله / باخت --- */
    this.$('btn-next').onclick = () => { this.click(); this.hideOverlays(); Game.startLevel(Game.lvl + 1); this.showScreen('game'); };
    this.$('btn-map1').onclick = () => { this.click(); this.exitToMap(); };
    this.$('btn-retry').onclick = () => { this.click(); this.restartLevel(); };
    this.$('btn-map2').onclick = () => { this.click(); this.exitToMap(); };
    this.$('btn-finale-map').onclick = () => { this.click(); this.exitToMap(); };

    /* --- ریست --- */
    this.$('btn-reset').onclick = () => {
      if (confirm('مطمئنی؟ همه سکه‌ها، الماس‌ها، اسکین‌ها و مراحل باز شده پاک می‌شوند!')) {
        Save.reset();
        this.refreshMoney();
        this.buildMenuContinue();
        alert('همه‌چیز پاک شد. از اول شروع کن! 🌱');
      }
    };

    /* --- صفحه‌کلید --- */
    window.addEventListener('keydown', e => this.onKey(e, true));
    window.addEventListener('keyup', e => this.onKey(e, false));
    /* اگر فوکوس پنجره از دست برود همه کلیدها رها می‌شوند تا بازیکن خودکار ندود */
    window.addEventListener('blur', () => resetKeys());
    /* بعد از کلیک، فوکوس دکمه گرفته می‌شود تا Space/Enter دکمه‌ی پنهان را دوباره فعال نکند */
    document.addEventListener('click', e => {
      const b = e.target.closest ? e.target.closest('button') : null;
      if (b) b.blur();
    });

    /* --- لمس --- */
    this.initTouch();

    /* --- توقف خودکار هنگام ترک صفحه --- */
    document.addEventListener('visibilitychange', () => this.onVisibilityChange(document.hidden));

    this.refreshMoney();
    this.refreshSoundBtn();
    this.buildMenuContinue();
    this.showScreen('menu');
  },

  /* مخفی شدن تب: بازی متوقف، موسیقی قطع و خروجی صدا معلق می‌شود.
     برگشتن: فقط صدا آماده می‌شود و بازی روی پوشش توقف می‌ماند؛ با «ادامه» موسیقی دوباره از اول شروع می‌شود. */
  onVisibilityChange(hidden) {
    if (hidden) {
      if (Game.state === 'play') this.pause();   // pause خودش موسیقی را هم قطع می‌کند
      AudioSys.stopMusic();
      AudioSys.suspend();
    } else {
      AudioSys.unsuspend();
      if (typeof C !== 'undefined') { C.last = 0; C.acc = 0; }   // بعد از برگشت، پرش زمانی نداشته باشیم
    }
  },

  click() { AudioSys.ensure(); AudioSys.sfx('click'); },

  /* ---------- صفحه‌ها ---------- */
  showScreen(name) {
    document.querySelectorAll('.screen').forEach(s => s.classList.remove('active'));
    this.$('screen-' + name).classList.add('active');
    if (name === 'menu') {
      Game.state = 'menu';
      AudioSys.stopMusic();
      this.refreshMoney();
      this.buildMenuContinue();
    }
    if (name === 'map') this.buildMap();
    if (name === 'shop') { this.buildShop(); this.refreshMoney(); }
  },

  buildMenuContinue() {
    const b = this.$('btn-continue');
    if (Save.data.unlocked > 1 || Save.data.completed.length > 0) {
      b.style.display = '';
      b.innerHTML = '▶️ ادامه از مرحله ' + faNum(Save.data.current);
    } else b.style.display = 'none';
  },

  /* ---------- نقشه مراحل ---------- */
  showMap() { this.showScreen('map'); },

  buildMap() {
    const grid = this.$('level-grid');
    grid.innerHTML = '';
    for (let lvl = 1; lvl <= TOTAL_LEVELS; lvl++) {
      const thKey = LEVEL_THEMASSIGN(lvl);
      const th = THEMES[thKey];
      const unlocked = lvl <= Save.data.unlocked;
      const done = Save.data.completed.includes(lvl);
      const hasTimer = !!TIMER_LEVELS[lvl];
      const card = document.createElement('div');
      card.className = 'lvl-card t-' + thKey + (unlocked ? '' : ' locked') + (done ? ' done' : '');
      if (unlocked) {
        card.onclick = () => { this.click(); Game.startLevel(lvl); this.showScreen('game'); };
        card.innerHTML = '<div class="num">' + faNum(lvl) + '</div><div class="name">' + th.fa + '</div>' +
          '<div class="tags">' + (hasTimer ? '⏱' : '') + (done ? '✔' : '') + '</div>';
      } else {
        card.innerHTML = '<div class="lock">🔒</div><div class="num">' + faNum(lvl) + '</div><div class="name">قفل است</div>';
      }
      grid.appendChild(card);
    }
    this.$('map-finished').style.display = Save.data.finished30 ? '' : 'none';
    this.refreshMoney();
  },

  /* ---------- فروشگاه ---------- */
  showShop() { this.showScreen('shop'); },

  buildShop() {
    const grid = this.$('shop-grid');
    grid.innerHTML = '';
    SKINS.forEach(s => {
      const owned = Save.data.owned.includes(s.id);
      const selected = Save.data.skin === s.id;
      const card = document.createElement('div');
      card.className = 'skin-card' + (selected ? ' selected' : '');

      /* پیش‌نمایش */
      const cv = document.createElement('canvas');
      cv.width = 96; cv.height = 96;
      const cctx = cv.getContext('2d');
      cctx.imageSmoothingEnabled = false;
      cctx.fillStyle = '#101736';
      cctx.fillRect(0, 0, 96, 96);
      cctx.fillStyle = '#1f2a5e';
      cctx.fillRect(0, 74, 96, 22);
      drawChar(cctx, 37, 18, 22, 44, s, { face: 1, walk: -1 });
      card.appendChild(cv);

      const nm = document.createElement('div');
      nm.className = 'sname'; nm.textContent = s.name;
      card.appendChild(nm);
      const ds = document.createElement('div');
      ds.className = 'sdesc'; ds.textContent = s.desc;
      card.appendChild(ds);

      const price = document.createElement('div');
      price.className = 'price';
      if (owned) price.innerHTML = selected ? '✅ انتخاب شد' : 'داری ✔';
      else {
        let html = '';
        if (s.priceC > 0) html += '<span class="p-coin">🪙 ' + faNum(s.priceC) + '</span>';
        if (s.priceD > 0) html += '<span class="p-diam">💎 ' + faNum(s.priceD) + '</span>';
        if (!html) html = '<span class="p-coin">🎁 رایگان</span>';
        price.innerHTML = html;
      }
      card.appendChild(price);

      const btn = document.createElement('button');
      btn.className = 'btn btn-mini';
      if (selected) { btn.textContent = '★ فعلی'; btn.disabled = true; }
      else if (owned) {
        btn.textContent = 'انتخاب';
        btn.onclick = () => { this.click(); Save.selectSkin(s.id); this.buildShop(); };
      } else {
        btn.textContent = 'خرید';
        const can = Save.data.coins >= s.priceC && Save.data.diamonds >= s.priceD;
        btn.disabled = !can;
        btn.classList.add(can ? 'btn-primary' : 'btn-danger');
        btn.onclick = () => {
          if (Save.spend(s.priceC, s.priceD)) {
            Save.ownSkin(s.id); Save.selectSkin(s.id);
            AudioSys.sfx('unlock');
            this.buildShop(); this.refreshMoney();
          }
        };
      }
      card.appendChild(btn);
      grid.appendChild(card);
    });
  },

  /* ---------- شروع / پایان مرحله ---------- */
  restartLevel() {
    this.hideOverlays();
    Game.startLevel(Game.lvl);
    this.showScreen('game');
  },

  exitToMap() {
    this.hideOverlays();
    Game.state = 'menu';
    AudioSys.stopMusic();
    this.showScreen('map');
  },

  onLevelComplete() {
    const isLast = Game.lvl >= TOTAL_LEVELS;
    if (isLast) {
      this.$('overlay-finale').style.display = 'flex';
      AudioSys.sfx('unlock');
    } else {
      const nxt = Math.min(Game.lvl + 1, TOTAL_LEVELS);
      this.$('complete-stats').innerHTML =
        '🪙 سکه: <b>' + faNum(Game.coinsRun) + '</b> &nbsp;|&nbsp; 💎 الماس: <b>' + faNum(Game.diamRun) + '</b>' +
        '<br>مرحله ' + faNum(nxt) + ' باز شد! 🔓';
      this.$('overlay-complete').style.display = 'flex';
    }
    this.refreshMoney();
  },

  onGameOver(reason) {
    this.$('over-title').textContent = reason === 'time' ? '⏱ زمان تمام شد!' : '💀 باختی!';
    this.$('over-reason').textContent = reason === 'time'
      ? 'زمان مرحله به پایان رسید — مرحله ' + faNum(Game.lvl) + ' را از اول شروع کن.'
      : 'قلب‌هایت تمام شد — مرحله ' + faNum(Game.lvl) + ' را از اول شروع کن.';
    this.$('overlay-over').style.display = 'flex';
    this.refreshMoney();
  },

  hideOverlays() {
    ['overlay-pause', 'overlay-complete', 'overlay-over', 'overlay-finale'].forEach(id => this.$(id).style.display = 'none');
  },

  pause() {
    if (Game.state !== 'play') return;
    Game.state = 'pause';
    resetKeys();
    this.$('overlay-pause').style.display = 'flex';
    AudioSys.stopMusic();
  },
  resume() {
    if (Game.state !== 'pause') return;
    Game.state = 'play';
    Keys.jumpP = false;
    this.$('overlay-pause').style.display = 'none';
    AudioSys.startMusic();
  },

  /* بنر شروع مرحله */
  showBanner() {
    const b = this.$('level-banner');
    if (!b || !Game.level) return;
    b.innerHTML = '<div class="in">' + Game.level.name +
      (Game.level.timer ? '<small>⏱ این مرحله تایمر دارد: ' + faNum(Game.level.timer) + ' ثانیه — اگر زمان تمام شود مرحله از اول شروع می‌شود!</small>' : '') +
      '</div>';
    b.classList.add('show');
    clearTimeout(this._bt);
    this._bt = setTimeout(() => b.classList.remove('show'), 2200);
  },

  /* ---------- HUD ---------- */
  updateHUD() {
    const G = Game, c = this._hudCache;
    const lv = 'مرحله ' + faNum(G.lvl);
    if (c.lv !== lv) { c.lv = lv; this.$('hud-level').textContent = lv; }

    const hearts = CHEAT_INF_HEARTS
      ? '❤️∞'
      : '❤'.repeat(G.hearts) + '🖤'.repeat(MAX_HEARTS - G.hearts);
    if (c.h !== hearts) { c.h = hearts; this.$('hud-hearts').textContent = hearts; }

    if (c.co !== G.coinsRun) { c.co = G.coinsRun; this.$('hud-coins').textContent = faNum(G.coinsRun); }
    if (c.di !== G.diamRun) { c.di = G.diamRun; this.$('hud-diamonds').textContent = faNum(G.diamRun); }

    /* دکمه موج شیطانی فقط با اسکین قهرمان شیطانی وسط بازی دیده می‌شود */
    this.updateWaveBtn();
    if (c.cn !== G.cones) { c.cn = G.cones; this.$('hud-cones').textContent = faNum(G.cones); }

    /* نشان سپر محافظ */
    const shEl = this.$('hud-shield');
    if (shEl) {
      const on = G.shield > 0;
      if (c.sh !== on) { c.sh = on; shEl.style.display = on ? '' : 'none'; }
    }

    const tEl = this.$('hud-timer');
    if (G.level.timer > 0) {
      tEl.style.display = '';
      const s = Math.max(0, Math.ceil(G.timeLeft));
      const mm = String(Math.floor(s / 60)).padStart(2, '0');
      const ss = String(s % 60).padStart(2, '0');
      const txt = '⏱ ' + faNum(mm) + ':' + faNum(ss);
      if (c.t !== txt) { c.t = txt; tEl.textContent = txt; }
      tEl.classList.toggle('danger', s <= 15);
    } else tEl.style.display = 'none';
  },

  refreshMoney() {
    const c = Save.data.coins, d = Save.data.diamonds;
    [['menu-coins', c], ['menu-diamonds', d], ['map-coins', c], ['map-diamonds', d], ['shop-coins', c], ['shop-diamonds', d]]
      .forEach(([id, v]) => { const el = this.$(id); if (el) el.textContent = faNum(v); });
  },

  /* دکمه لمسی موج شیطانی: کنار دکمه شلیک، فقط وسط بازی و فقط با اسکین قهرمان شیطانی */
  updateWaveBtn() {
    const wb = this.$('tc-wave');
    if (!wb) return;
    const show = Game.state === 'play' && Save.data.skin === 'demon';
    const sig = show ? (Game.waveLeft || 0) : -1;
    if (this._hudCache.wv === sig) return;
    this._hudCache.wv = sig;
    wb.style.display = show ? '' : 'none';
    if (show) wb.innerHTML = '🌊<b class="wv-n">' + faNum(Game.waveLeft || 0) + '</b>';
  },

  refreshSoundBtn() {
    this.$('btn-sound').textContent = Save.data.sound ? '🔊 صدا: روشن' : '🔇 صدا: خاموش';
  },

  /* ---------- صفحه‌کلید ---------- */
  onKey(e, down) {
    const inGame = document.getElementById('screen-game').classList.contains('active');
    const code = e.code;
    if (['ArrowLeft', 'ArrowRight', 'ArrowUp', 'ArrowDown', 'Space'].includes(code)) e.preventDefault();

    /* توقف / ادامه با P یا Esc */
    if (down && (code === 'KeyP' || code === 'Escape') && inGame) {
      if (Game.state === 'play') this.pause();
      else if (Game.state === 'pause') this.resume();
      return;
    }

    /* رها کردن کلید در هر حالتی پردازش می‌شود — وگرنه کلید «گیر می‌کند»
       و بازیکن از مرحله‌ی بعد بدون فشردن دکمه خودش می‌دود */
    if (!down) {
      switch (code) {
        case 'ArrowLeft': case 'KeyA': Keys.left = false; break;
        case 'ArrowRight': case 'KeyD': Keys.right = false; break;
        case 'Space': case 'ArrowUp': case 'KeyW': Keys.jump = false; break;
        case 'KeyX': case 'KeyF': Keys.shoot = false; break;
      }
      return;
    }

    /* فشردن کلید فقط وسط بازی معنا دارد */
    if (Game.state !== 'play') return;
    switch (code) {
      case 'ArrowLeft': case 'KeyA': Keys.left = true; break;
      case 'ArrowRight': case 'KeyD': Keys.right = true; break;
      case 'Space': case 'ArrowUp': case 'KeyW':
        if (!Keys.jump) Keys.jumpP = true;
        Keys.jump = true; break;
      case 'KeyX': case 'KeyF': Keys.shoot = true; break;
      case 'KeyJ': Game.devilWave(); break;   /* موج شیطانی */
    }
  },

  /* ---------- کنترل لمسی ---------- */
  initTouch() {
    this.updateTouchMode();
    window.addEventListener('resize', () => this.updateTouchMode());

    const bind = (id, on, off) => {
      const el = this.$(id);
      const start = e => { e.preventDefault(); AudioSys.ensure(); on(); };
      const end = e => { e.preventDefault(); off(); };
      el.addEventListener('pointerdown', start);
      el.addEventListener('pointerup', end);
      el.addEventListener('pointercancel', end);
      el.addEventListener('pointerleave', end);
    };
    bind('tc-left', () => Keys.left = true, () => Keys.left = false);
    bind('tc-right', () => Keys.right = true, () => Keys.right = false);
    bind('tc-jump', () => { if (!Keys.jump) Keys.jumpP = true; Keys.jump = true; }, () => Keys.jump = false);
    bind('tc-shoot', () => Keys.shoot = true, () => Keys.shoot = false);
  },

  updateTouchMode() {
    const isTouch = ('ontouchstart' in window) ||
      (navigator.maxTouchPoints > 0) ||
      (window.matchMedia && matchMedia('(pointer: coarse)').matches) ||
      window.innerWidth < 820;
    this.$('touch-controls').style.display = isTouch ? '' : 'none';
  }
};
