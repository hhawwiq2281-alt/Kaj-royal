/* ============================================================
   سوپر کاج — مراحل: تم‌ها، تولید مرحله با بذر ثابت، دشمنان
   ============================================================ */
'use strict';

/* ---------- انواع خانه‌های شبکه ---------- */
const T_EMPTY = 0, T_GROUND = 1, T_BRICK = 2, T_PLAT = 3,
  T_COIN = 4, T_DIAM = 5, T_CONE = 6, T_SPIKE = 7, T_CHECK = 8,
  T_HEART = 9, T_SHIELD = 10;

/* ---------- تم‌های پنج‌گانه ---------- */
const THEMES = {
  grass: {
    fa: 'دشت سرسبز', skyTop: '#63b4ff', skyBot: '#c6ecff',
    hill: '#3f9e4f', hill2: '#2b6e3a', cloud: '#ffffff',
    gTop: '#3fae49', gBody: '#8a5a2b', gDark: '#6e4520',
    brick: '#c96a2a', brickDark: '#9c4f1e', plat: '#3fae49', platLeg: '#8a5a2b',
    deco: 'bush'
  },
  desert: {
    fa: 'کویر طلایی', skyTop: '#ffd28c', skyBot: '#fff0d0',
    hill: '#e8b957', hill2: '#c98f37', cloud: '#fff7e8',
    gTop: '#f0c060', gBody: '#d99a3d', gDark: '#b07a28',
    brick: '#d9823d', brickDark: '#a95f28', plat: '#f0c060', platLeg: '#d99a3d',
    deco: 'cactus'
  },
  ice: {
    fa: 'سرزمین یخی', skyTop: '#8fd0f5', skyBot: '#eaf8ff',
    hill: '#a8d8f0', hill2: '#7ab8dc', cloud: '#ffffff',
    gTop: '#eaf7ff', gBody: '#9fc9e8', gDark: '#7aa8cc',
    brick: '#7ec8e8', brickDark: '#5a9fc4', plat: '#eaf7ff', platLeg: '#9fc9e8',
    deco: 'pine', slippery: true, snow: true
  },
  volcano: {
    fa: 'آتشفشان', skyTop: '#2b1024', skyBot: '#8a2c14',
    hill: '#4a1f1a', hill2: '#331410', cloud: '#5a2a20',
    gTop: '#6b3a2a', gBody: '#3c241c', gDark: '#2a1812',
    brick: '#8a4430', brickDark: '#5e2c1e', plat: '#6b3a2a', platLeg: '#3c241c',
    deco: 'rock', ember: true
  },
  night: {
    fa: 'قلعه شب', skyTop: '#0b1035', skyBot: '#2c3470',
    hill: '#232552', hill2: '#1a1c40', cloud: '#39406e',
    gTop: '#5a5f8a', gBody: '#34395c', gDark: '#23274a',
    brick: '#4a5078', brickDark: '#33385c', plat: '#5a5f8a', platLeg: '#34395c',
    deco: 'torch', stars: true, moon: true
  }
};

/* مراحل ۱ تا ۱۵ مثل قبل؛ ۱۶ تا ۳۰ همان ۵ تم را با سختی بیشتر تکرار می‌کنند */
const LEVEL_THEMASSIGN = lvl => lvl <= 15
  ? (lvl <= 3 ? 'grass' : lvl <= 6 ? 'desert' : lvl <= 9 ? 'ice' : lvl <= 12 ? 'volcano' : 'night')
  : LEVEL_THEMASSIGN(lvl - 15);

/* مراحل دارای تایمر: شماره → ثانیه */
const TIMER_LEVELS = { 3: 110, 7: 130, 8: 140, 12: 150, 14: 180, 15: 220, 18: 170, 21: 190, 24: 200, 27: 220, 30: 260 };

/* ---------- تولید مرحله (همیشه یکسان با بذر ثابت) ---------- */
function generateLevel(lvl) {
  const rng = mulberry32(lvl * 7919 + 1013);
  const diff = lvl;
  const w = Math.min(88 + lvl * 9, 235);
  const theme = LEVEL_THEMASSIGN(lvl);
  const th = THEMES[theme];

  const grid = new Uint8Array(w * ROWS);
  const SG = (x, y, v) => { if (x >= 0 && x < w && y >= 0 && y < ROWS) grid[y * w + x] = v; };
  const GT = (x, y) => (x < 0 || x >= w || y < 0 || y >= ROWS) ? 0 : grid[y * w + x];

  const top = new Int16Array(w).fill(-1);   // ردیف بالایی زمین در هر ستون (-1 = پرتگاه)
  const fillGround = (x1, x2, t) => {
    t = clamp(t, 5, 15);
    for (let x = x1; x <= x2 && x < w; x++) {
      top[x] = t;
      for (let y = t; y < ROWS; y++) SG(x, y, T_GROUND);
    }
  };

  const enemies = [];      // {tx,type,min,max}  tx = ستون
  const coinSpots = [];    // [x,y]
  const diaSpots = [];     // [x,y]
  let coinBudget = 24 + diff * 3;
  let budget = {
    walker: 3 + Math.round(diff * 0.9),
    spiky: diff >= 5 ? Math.floor((diff - 3) / 2) : 0,
    /* پرنده‌ها فقط تا مرحله ۱۶ و از ۲۴ به بعد — مراحل ۱۷ تا ۲۳ بدون پرنده */
    flyer: (diff >= 7 && !(diff >= 17 && diff <= 23)) ? Math.floor((diff - 5) / 2) : 0
  };
  const pickEnemy = () => {
    if (budget.spiky > 0) { budget.spiky--; return 'spiky'; }
    if (budget.flyer > 0) { budget.flyer--; return 'flyer'; }
    if (budget.walker > 0) { budget.walker--; return 'walker'; }
    return null;
  };
  const addCoinsRow = (x1, x2, y) => {
    for (let x = x1; x <= x2 && x < w; x++) {
      if (coinBudget <= 0) return;
      if (GT(x, y) === T_EMPTY && GT(x, y - 1) === T_EMPTY) { SG(x, y, T_COIN); coinBudget--; }
    }
  };
  const addCoinArc = (x1, x2, yBase) => {
    // قوس سکه روی پرتگاه
    const n = x2 - x1 + 1, mid = (n - 1) / 2;
    for (let i = 0; i < n; i++) {
      if (coinBudget <= 0) return;
      const y = Math.round(yBase - (1.6 - Math.abs(i - mid) * (3.2 / Math.max(n, 1))));
      if (GT(x1 + i, y) === T_EMPTY) { SG(x1 + i, y, T_COIN); coinBudget--; }
    }
  };

  /* شروع امن */
  fillGround(0, 9, 14);
  let t = 14;
  let tMin = 11;   // کف ارتفاع مجاز — بعد از بخش صعود به ۵ تغییر می‌کند (مراحل ۱۶+)
  let x = 10;
  let lastWasPit = false;
  const endZone = w - 15;

  /* 🪜 برنامه‌ی بخش‌های صعودی — فقط مراحل ۱۶ به بعد (مثل ۱۶ و ۱۹ و ۲۲ و ...)
     تا بذرِ مراحل ۱ تا ۱۵ هیچ تغییری نکند، این شرط فقط برای diff>=16 فعال است */
  const climbPlan = [];
  let hasClimb = false;   // فقط مراحلی که واقعاً پله‌های صعودی دارند → اسکرول عمودی
  if (diff >= 16 && diff % 3 === 1) {
    climbPlan.push({ at: Math.floor(endZone * 0.35) });
    if (diff >= 28) climbPlan.push({ at: Math.floor(endZone * 0.70) });
  }

  while (x < endZone) {
    let feat;
    const r = rng();
    if (lastWasPit) feat = 'flat';
    else if (r < 0.30) feat = 'flat';
    else if (r < 0.30 + 0.14 + diff * 0.006) feat = 'pit';
    else if (r < 0.55 + diff * 0.008) feat = 'platpit';
    else if (r < 0.70) feat = 'hill';
    else if (r < 0.80) feat = 'stairs';
    else if (r < 0.90) feat = 'pillars';
    else feat = diff >= 5 ? 'spikes' : 'flat';

    /* 🪜 رسیدن به نقطه‌ی برنامه‌ریزی‌شده‌ی صعود — فقط روی زمینِ صاف و فقط مراحل ۱۶+ */
    if (climbPlan.length && !lastWasPit && x >= climbPlan[0].at) {
      feat = 'climb';
      climbPlan.shift();
    }

    if (feat === 'flat') {
      /* تغییر ارتفاع ملایم گاهی */
      if (!lastWasPit && rng() < 0.35) t = clamp(t + (rng() < 0.5 ? -1 : 1), tMin, 14);
      const len = rndi(rng, 5, 9);
      fillGround(x, x + len - 1, t);
      if (rng() < 0.55) addCoinsRow(x + 1, x + len - 2, t - 2);
      if (len >= 6 && x > 14) {
        const et = pickEnemy();
        if (et && et !== 'flyer') enemies.push({ tx: x + Math.floor(len / 2), type: et, min: x + 1, max: x + len - 2 });
        else if (et === 'flyer') budget.flyer++; // پرنده جای بهتری دارد
      }
      x += len; lastWasPit = false;
    }
    else if (feat === 'pit') {
      const gap = clamp(2 + (rng() < 0.2 + diff * 0.02 ? 1 : 0) + (diff >= 10 && rng() < 0.3 ? 1 : 0), 2, 4);
      addCoinArc(x, x + gap - 1, t - 3);
      if (diff >= 7 && rng() < 0.35 && budget.flyer > 0) {
        budget.flyer--;
        enemies.push({ tx: x + Math.floor(gap / 2), type: 'flyer', min: x - 3, max: x + gap + 3 });
      }
      x += gap; lastWasPit = true;
    }
    else if (feat === 'platpit') {
      /* پرتگاه عریض با سکوی پرشی */
      const gap = rndi(rng, diff >= 6 ? 6 : 5, diff >= 8 ? 9 : 7);
      const py = t - 2;
      const p1 = x + 1;
      const p1w = 2;
      for (let i = 0; i < p1w; i++) SG(p1 + i, py, T_PLAT);
      addCoinsRow(p1, p1 + p1w - 1, py - 2);
      let p2 = -1;
      if (gap >= 7) {
        p2 = x + gap - 3;
        for (let i = 0; i < 2; i++) SG(p2 + i, py - (rng() < 0.4 ? 1 : 0), T_PLAT);
        if (rng() < 0.5) addCoinsRow(p2, p2 + 1, py - 4);
      }
      diaSpots.push([p1, py - 3]);
      if (diff >= 7 && rng() < 0.4 && budget.flyer > 0) {
        budget.flyer--;
        enemies.push({ tx: x + Math.floor(gap / 2), type: 'flyer', min: x - 2, max: x + gap + 2 });
      }
      x += gap; lastWasPit = true;
    }
    else if (feat === 'hill') {
      /* تپه: بالا و پایین پله‌ای */
      const rise = rndi(rng, 1, 2);
      for (let i = 1; i <= rise; i++) { fillGround(x, x + 1, t - i); }
      x += 2;
      const plate = rndi(rng, 3, 5);
      fillGround(x, x + plate - 1, t - rise);
      if (rng() < 0.5) addCoinsRow(x, x + plate - 1, t - rise - 2);
      if (rng() < 0.6) {
        const et = pickEnemy();
        if (et && et !== 'flyer') enemies.push({ tx: x + 1, type: et, min: x, max: x + plate - 1 });
        else if (et === 'flyer') budget.flyer++;
      }
      x += plate;
      for (let i = rise; i >= 1; i--) { fillGround(x, x + 1, t - i); }
      x += 2; lastWasPit = false;
    }
    else if (feat === 'stairs') {
      /* پلکان آجری مثل پایان مرحله‌های ماریو */
      const h = rndi(rng, 2, 3);
      const base = 4;
      fillGround(x, x + h * 2 + base + 2, t);
      for (let i = 1; i <= h; i++) {
        for (let y = t - 1; y >= t - i; y--) SG(x + i - 1, y, T_BRICK);
      }
      diaSpots.push([x + h - 1, t - h - 1]);
      addCoinsRow(x + h, x + h + base - 1, t - 2);
      for (let i = h; i >= 1; i--) {
        for (let y = t - 1; y >= t - i; y--) SG(x + h + base + (h - i), y, T_BRICK);
      }
      x += h * 2 + base + 3; lastWasPit = false;
    }
    else if (feat === 'pillars') {
      const len = 8;
      fillGround(x, x + len - 1, t);
      const p1 = x + 2, h1 = rndi(rng, 1, 2);
      for (let y = t - 1; y >= t - h1; y--) SG(p1, y, T_BRICK);
      if (len > 6) {
        const p2 = x + 5, h2 = rndi(rng, 1, 2);
        for (let y = t - 1; y >= t - h2; y--) SG(p2, y, T_BRICK);
      }
      addCoinsRow(p1, p1, t - h1 - 2);
      if (x > 14) {
        const et = pickEnemy();
        if (et && et !== 'flyer') enemies.push({ tx: x + 7, type: et, min: x, max: x + len - 1 });
        else if (et === 'flyer') budget.flyer++;
      }
      x += len; lastWasPit = false;
    }
    else if (feat === 'climb') {
      /* 🪜 بخش صعود مثل ماریو: اول در ارتفاع پایین، بعد سکوهای معلق صعودی
         روی پرتگاه، و ادامه‌ی مرحله روی سطح صافِ مرتفع */
      const runLen = rndi(rng, 5, 7);
      fillGround(x, x + runLen - 1, t);
      if (rng() < 0.6) addCoinsRow(x + 1, x + runLen - 2, t - 2);
      x += runLen;

      const rise = Math.min(rndi(rng, 3, 4), Math.floor((t - 6) / 2));
      if (rise < 2) {
        /* ارتفاع زیادی بالا نیستیم — به‌جای صعود، گذر از پرتگاه عریض با سکوهای هم‌سطح */
        const gap = rndi(rng, 6, 8);
        SG(x + 1, t - 2, T_PLAT); SG(x + 2, t - 2, T_PLAT);
        SG(x + gap - 2, t - 2, T_PLAT); SG(x + gap - 1, t - 2, T_PLAT);
        addCoinsRow(x + 1, x + 2, t - 4);
        if (rng() < 0.5) diaSpots.push([x + 1, t - 5]);
        x += gap; lastWasPit = true;
      } else {
      hasClimb = true;   // سکوهای معلق صعودی واقعی ساخته شد → این مرحله اسکرول عمودی دارد
      const gapX = diff >= 24 ? 3 : rndi(rng, 2, 3);
      let py = t - 2, platX = x;
      for (let i = 0; i < rise; i++) {
        platX = x + i * (2 + gapX);
        for (let k = 0; k < 2; k++) SG(platX + k, py, T_PLAT);
        addCoinsRow(platX, platX + 1, py - 2);
        /* چالش: خار روی بعضی سکوهای وسط (مراحل ۲۲ به بعد) */
        if (diff >= 22 && i > 0 && i < rise - 1 && rng() < 0.4)
          SG(platX + (rng() < 0.5 ? 0 : 1), py - 1, T_SPIKE);
        py -= 2;
      }
      const newT = py + 2;              // ردیف سطح مرتفع = ردیف آخرین سکو
      const gStart = platX + 3;
      const highLen = rndi(rng, 12, 16);
      fillGround(gStart, gStart + highLen - 1, newT);
      addCoinsRow(gStart + 2, gStart + highLen - 3, newT - 2);
      diaSpots.push([gStart + 2, newT - 4]);   // الماس جایزه روی سطح بالا
      const et = pickEnemy();
      if (et && et !== 'flyer') enemies.push({ tx: gStart + Math.floor(highLen / 2), type: et, min: gStart + 1, max: gStart + highLen - 2 });
      x = gStart + highLen;
      t = newT;
      tMin = 5;
      lastWasPit = false;
      }
    }
    else { /* spikes */
      const len = rndi(rng, 7, 9);
      fillGround(x, x + len - 1, t);
      const s1 = x + 2, s2 = x + Math.min(len - 2, 5);
      SG(s1, t - 1, T_SPIKE);
      if (s2 !== s1) SG(s2, t - 1, T_SPIKE);
      addCoinsRow(s1, s1 + 1, t - 4);
      diaSpots.push([s1, t - 5]);
      x += len; lastWasPit = false;
    }
  }

  /* منطقه پایان: زمین صاف تا انتها (در ارتفاعی که مرحله به آن رسیده) */
  const endTop = clamp(t, tMin, 14);
  fillGround(x, w - 1, endTop);
  const flagTx = w - 7;

  /* پخش باقی‌مانده دشمنان روی زمین‌های مناسب (برای سختی کامل) */
  const tryPlaceGround = (type) => {
    for (let att = 0; att < 50; att++) {
      const ex = rndi(rng, 14, w - 15);
      if (top[ex] > 0 && GT(ex, top[ex] - 1) === T_EMPTY && GT(ex + 1, top[ex] - 1) === T_EMPTY && GT(ex + 2, top[ex] - 1) === T_EMPTY) {
        let near = false;
        for (const e of enemies) if (e.type !== 'flyer' && Math.abs(e.tx - ex) < 7) { near = true; break; }
        if (!near) { enemies.push({ tx: ex, type, min: ex - 4, max: ex + 6 }); return true; }
      }
    }
    return false;
  };
  while (budget.walker > 0 && tryPlaceGround('walker')) budget.walker--;
  while (budget.spiky > 0 && tryPlaceGround('spiky')) budget.spiky--;
  while (budget.flyer > 0) {
    const fx2 = rndi(rng, 14, w - 15);
    enemies.push({ tx: fx2, type: 'flyer', min: fx2 - 3, max: fx2 + 3 });
    budget.flyer--;
  }

  /* کاج‌ها (مهمات شلیک) در سه نقطه */
  const coneFr = [0.32, 0.55, 0.8];
  coneFr.forEach(f => {
    const cx = clamp(Math.floor(w * f), 12, w - 12);
    if (top[cx] > 0) SG(cx, top[cx] - 1, T_CONE);
  });

  /* الماس‌ها: از نقاط سخت انتخاب می‌شوند */
  const diaCount = 2 + (diff >= 4 ? 1 : 0) + (diff >= 9 ? 1 : 0) + (diff >= 13 ? 1 : 0);
  let placed = 0;
  for (let i = diaSpots.length - 1; i > 0; i--) {
    const j = Math.floor(rng() * (i + 1));
    [diaSpots[i], diaSpots[j]] = [diaSpots[j], diaSpots[i]];
  }
  for (const [dx, dy] of diaSpots) {
    if (placed >= diaCount) break;
    if (GT(dx, dy) === T_EMPTY && GT(dx, dy - 1) === T_EMPTY) { SG(dx, dy, T_DIAM); placed++; }
  }
  /* اگر جا کم بود، در ارتفاع بالای مسیر */
  let bx = 14;
  while (placed < diaCount && bx < w - 10) {
    if (top[bx] > 0 && GT(bx, top[bx] - 4) === T_EMPTY && GT(bx + 1, top[bx] - 4) === T_EMPTY) {
      SG(bx, top[bx] - 4, T_DIAM); placed++;
      bx += 9;
    } else bx++;
  }

  /* سکه‌های باقی‌مانده روی مسیر پخش کن */
  let sx = 12;
  while (coinBudget > 0 && sx < w - 10) {
    if (top[sx] > 0 && GT(sx, top[sx] - 2) === T_EMPTY) {
      SG(sx, top[sx] - 2, T_COIN); coinBudget--;
      sx += rng() < 0.5 ? 2 : 3;
    } else sx++;
  }

  /* نقطه بازگشت (چک‌پوینت) در میانه مرحله */
  let checkTx = null;
  const cx0 = Math.floor(w * 0.55);
  for (let dx = 0; dx < 10; dx++) {
    const cxx = cx0 + (dx % 2 === 0 ? dx : -dx);
    if (cxx > 12 && cxx < w - 12 && top[cxx] > 0 && GT(cxx, top[cxx] - 1) === T_EMPTY && GT(cxx, top[cxx] - 2) === T_EMPTY) {
      SG(cxx, top[cxx] - 1, T_CHECK);
      checkTx = cxx;
      break;
    }
  }

  /* ---------- آیتم‌های ویژه: سپر محافظ و قلب اضافه ---------- */
  /* یافتن خانه امن: زمین دارد، دو خانه بالایش خالی است، کنار خار/چک‌پوینت نیست */
  const findSafeSpot = (f0, f1, avoidTx, minDist) => {
    const a = Math.max(12, Math.floor(w * f0));
    const b = Math.min(w - 14, Math.floor(w * f1));
    for (let att = 0; att < 80; att++) {
      const cx = rndi(rng, a, b);
      const ty = top[cx];
      if (ty <= 0) continue;
      if (GT(cx, ty - 1) !== T_EMPTY || GT(cx, ty - 2) !== T_EMPTY) continue;
      if (GT(cx - 1, ty - 1) === T_SPIKE || GT(cx + 1, ty - 1) === T_SPIKE) continue;
      if (avoidTx != null && Math.abs(cx - avoidTx) < (minDist || 5)) continue;
      return [cx, ty - 1];
    }
    return null;
  };
  /* 🛡️ سپر محافظ — یک عدد در نیمه اول مرحله */
  const sSpot = findSafeSpot(0.30, 0.48, null) || findSafeSpot(0.14, 0.30, null);
  if (sSpot) SG(sSpot[0], sSpot[1], T_SHIELD);
  /* ❤️ قلب اضافه — یک عدد در میانه تا دوم مرحله، کمی دور از چک‌پوینت */
  const hSpot = findSafeSpot(0.58, 0.82, checkTx, 5) || findSafeSpot(0.83, 0.90, null) || findSafeSpot(0.48, 0.58, checkTx, 5);
  if (hSpot) SG(hSpot[0], hSpot[1], T_HEART);

  /* تزئینات پس‌زمینه */
  const clouds = [], hills = [], stars = [];
  for (let i = 0; i < Math.floor(w / 14); i++)
    clouds.push({ x: rng() * w * TILE, y: 30 + rng() * 130, s: 0.7 + rng() * 0.9 });
  for (let i = 0; i < Math.floor(w / 10); i++)
    hills.push({ x: rng() * w * TILE, r: 60 + rng() * 110, layer: rng() < 0.5 ? 0 : 1 });
  if (th.stars) for (let i = 0; i < 60; i++)
    stars.push({ x: rng() * w * TILE, y: rng() * 300, s: rng() < 0.2 ? 2 : 1 });

  const timer = TIMER_LEVELS[lvl] || 0;
  const spawnY = top[2] * TILE - 44;

  return {
    lvl, theme, th, w, grid, top, hasClimb,
    name: 'مرحله ' + faNum(lvl) + ' • ' + th.fa,
    spawnX: 2 * TILE, spawnY,
    flagX: flagTx * TILE,
    castleX: (w - 4) * TILE,
    checkTx, timer,
    enemies,
    clouds, hills, stars,
    seed: lvl
  };
}

/* کش ساده تا مرحله دوباره‌سازی نشود */
const LevelCache = {};
function getLevel(lvl) {
  if (!LevelCache[lvl]) LevelCache[lvl] = generateLevel(lvl);
  return LevelCache[lvl];
}
