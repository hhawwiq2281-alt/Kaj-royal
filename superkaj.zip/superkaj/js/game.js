/* ============================================================
   سوپر کاج — موتور بازی: فیزیک، دشمنان، شلیک، رندر پیکسلی
   ============================================================ */
'use strict';

/* ---------- ورودی (ui.js آن را پر می‌کند) ---------- */
const Keys = { left: false, right: false, jump: false, jumpP: false, shoot: false, shootP: false };

/* رها کردن همه‌ی کلیدها — هنگام شروع مرحله، پایان، باخت و توقف صدا زده می‌شود
   تا اگر بازیکن کلیدی را نگه داشته بود، کلید «گیر نکند» و شخصیت خودکار نود */
function resetKeys() { Keys.left = Keys.right = Keys.jump = Keys.jumpP = Keys.shoot = Keys.shootP = false; }

const GRAV = 0.55, MAXFALL = 13, RUNSPD = 4.4, JUMPV = 12.2;

const Game = {
  state: 'menu',          // menu | play | pause | complete | over | finale
  level: null, lvl: 1,
  camX: 0, camY: 0, camTargetY: 0, camMinY: 0, camMaxY: 0, tick: 0,
  P: null, enemies: [], shots: [], parts: [], texts: [],
  hearts: 3, cones: 0, coinsRun: 0, diamRun: 0,
  timeLeft: 0, respawnX: 0, checkActive: false, shield: 0,
  shootCool: 0, _skyGrad: null, _hudCache: {},

  /* ============ شروع مرحله ============ */
  startLevel(lvl) {
    this.lvl = lvl;
    /* هر بار مرحله از نو ساخته می‌شود تا همه‌ی سکه‌ها، کاج‌ها، قلب، سپر و
       پرچم بازگشت دوباره سر جای‌شان برگردند (بذر ثابت = دقیقاً همان نقشه) */
    this.level = generateLevel(lvl);
    const L = this.level;
    this.enemies = []; this.shots = []; this.parts = []; this.texts = [];
    this.hearts = MAX_HEARTS; this.cones = 0;
    /* قابلیت‌های اسکین‌ها: زره مرد زرهی + شمارنده موج شیطانی */
    this.armorHits = 0; this.armorLastHit = -9999;
    this.waveLeft = 3; this.waveFx = null;
    this.coinsRun = 0; this.diamRun = 0;
    this.timeLeft = L.timer; this.checkActive = false; this.shield = 0;
    this.respawnX = L.spawnX; this.camX = 0; this.camY = 0; this.camTargetY = 0; this.tick = 0;
    this.setupCameraBounds();
    this._skyGrad = null;

    this.P = {
      x: L.spawnX, y: L.spawnY, w: 22, h: 36,
      vx: 0, vy: 0, onGround: false, coyote: 0, jbuf: 0,
      face: 1, anim: 0, invuln: 0, jumping: false
    };

    /* ساخت دشمنان از نقشه مرحله */
    const spdW = 0.7 + lvl * 0.05, spdS = 0.55 + lvl * 0.045;
    L.enemies.forEach(p => {
      const gt = (L.top[p.tx] > 0 ? L.top[p.tx] : 14);
      if (p.type === 'flyer') {
        const cx = ((p.min + p.max) / 2) * TILE;
        const range = clamp((p.max - p.min) * TILE / 2 - 24, 40, 170);
        this.enemies.push({
          type: 'flyer', x: cx, y: gt * TILE - 105, x0: cx, y0: gt * TILE - 105,
          w: 28, h: 20, range, a: (p.tx % 7),
          dead: false, deadT: 0, dir: 1
        });
      } else {
        const h = 24, wd = 24;
        this.enemies.push({
          type: p.type, x: p.tx * TILE + 4, y: gt * TILE - h - 2, w: wd, h,
          dir: -1, speed: p.type === 'spiky' ? spdS : spdW,
          min: p.min * TILE, max: (p.max + 1) * TILE,
          vy: 0, onGround: false, dead: false, deadT: 0, t: 0
        });
      }
    });

    this.state = 'play';
    resetKeys();
    /* هر پوشش باز (پایان مرحله، باخت، توقف) بسته شود تا جلوی دید نماند */
    if (typeof UI !== 'undefined' && UI.hideOverlays) UI.hideOverlays();
    Save.startLevel(lvl);
    AudioSys.startMusic();
    if (typeof UI !== 'undefined') UI.showBanner();
  },

  /* ============ حلقه گام ============ */
  step() {
    this.tick++;
    const L = this.level, P = this.P;

    /* --- تایمر --- */
    if (L.timer > 0) {
      this.timeLeft -= 1 / 60;
      if (this.timeLeft <= 0) { this.timeLeft = 0; return this.gameOver('time'); }
    }

    /* --- حرکت افقی --- */
    const icy = L.th.slippery;
    const acc = P.onGround ? (icy ? 0.22 : 0.55) : 0.4;
    if (Keys.left && !Keys.right) { P.vx -= acc; P.face = -1; }
    else if (Keys.right && !Keys.left) { P.vx += acc; P.face = 1; }
    else {
      P.vx *= P.onGround ? (icy ? 0.965 : 0.78) : 0.98;
      if (Math.abs(P.vx) < 0.05) P.vx = 0;
    }
    P.vx = clamp(P.vx, -RUNSPD, RUNSPD);

    /* --- پرش --- */
    if (Keys.jumpP) { P.jbuf = 7; Keys.jumpP = false; }
    if (P.jbuf > 0 && (P.onGround || P.coyote > 0)) {
      P.vy = -JUMPV; P.onGround = false; P.coyote = 0; P.jbuf = 0;
      P.jumping = true;   // فقط صعودِ ناشی از پرش قابل بریدن است (نه جهش له‌کردن دشمن یا عقب‌زدگی)
      AudioSys.sfx('jump');
      this.dust(P.x + P.w / 2, P.y + P.h);
    }
    if (P.jbuf > 0) P.jbuf--;
    if (P.vy >= 0 || P.onGround) P.jumping = false;
    if (P.jumping && !Keys.jump && P.vy < -4.5) P.vy = -4.5;   // پرش متغیر: رها کردن زودهنگام دکمه

    /* --- جاذبه --- */
    P.vy = Math.min(P.vy + GRAV, MAXFALL);

    /* --- برخورد کاشی‌ها --- */
    const wasGround = P.onGround;
    this.moveX(P, P.vx);
    P.onGround = false;
    this.moveY(P, P.vy);
    if (P.onGround) P.coyote = 7;
    else if (wasGround && P.coyote <= 0) P.coyote = 7;
    else if (P.coyote > 0) P.coyote--;
    P.anim += Math.abs(P.vx);
    if (P.invuln > 0) P.invuln--;
    if (P.shootPose > 0) P.shootPose--;

    /* محدود به دنیا */
    if (P.x < 0) { P.x = 0; P.vx = 0; }
    const worldW = L.w * TILE;
    if (P.x + P.w > worldW) { P.x = worldW - P.w; P.vx = 0; }

    /* --- شلیک کاج --- */
    if (this.shootCool > 0) this.shootCool--;
    if (Keys.shoot && this.shootCool <= 0) {
      if (this.cones > 0) {
        this.cones--; this.shootCool = 18; P.shootPose = 12;
        this.shots.push({
          x: P.face > 0 ? P.x + P.w : P.x - 12, y: P.y + 12,
          w: 12, h: 12, vx: P.face * 9.5, life: 120, rot: 0
        });
        AudioSys.sfx('shoot');
      } else {
        AudioSys.sfx('empty'); this.shootCool = 12;
      }
    }

    /* --- تیرها --- */
    for (let i = this.shots.length - 1; i >= 0; i--) {
      const s = this.shots[i];
      s.x += s.vx; s.life--; s.rot += 0.3;
      let dead = s.life <= 0;
      const tx = Math.floor((s.vx > 0 ? s.x + s.w : s.x) / TILE), ty = Math.floor((s.y + s.h / 2) / TILE);
      if (this.solidT(this.GT(tx, ty))) dead = true;
      if (!dead) {
        for (const e of this.enemies) {
          if (e.dead) continue;
          if (rectHit(s, e)) {
            this.killEnemy(e, true); dead = true; break;
          }
        }
      }
      if (dead) { this.poof(s.x + 6, s.y + 6, '#c98a4b'); this.shots.splice(i, 1); }
    }

    /* --- آیتم‌ها و خطرها (کاشی‌ها) --- */
    this.tileInteract();

    /* --- دشمنان --- */
    this.updateEnemies();

    /* --- برخورد بازیکن و دشمن --- */
    if (P.invuln <= 0) {
      for (const e of this.enemies) {
        if (e.dead) continue;
        if (rectHit(P, e)) {
          const fromTop = P.vy > 0.5 && (P.y + P.h) - e.y < e.h * 0.7;
          /* مرد زرهی تنها اسکینی است که با پرش، دشمن تیغ‌دار را هم له می‌کند */
          if (fromTop && (e.type !== 'spiky' || Save.data.skin === 'armor')) this.stomp(e);
          else this.hurt();
          break;
        }
      }
    }

    /* --- سقوط در پرتگاه --- */
    if (P.y > VIEW_H + 60) this.fallPenalty();

    /* --- پرچم پایان --- */
    if (P.x + P.w >= L.flagX + 6) return this.completeLevel();

    /* --- دوربین --- */
    const target = clamp(P.x + P.w / 2 - VIEW_W * 0.42, 0, worldW - VIEW_W);
    this.camX = lerp(this.camX, target, 0.12);
    if (this.camX < 0) this.camX = 0;
    /* دوربین عمودی دوطرفه (Vertical Follow) — جزئیات در updateCamera */
    this.updateCamera(false);

    /* --- ذرات و متن‌ها --- */
    this.updateParts();
    this.ambient();
    /* انبساط حلقه موج شیطانی */
    if (this.waveFx) {
      const w = this.waveFx;
      w.r += (w.max - w.r) * 0.22;
      if (--w.life <= 0) this.waveFx = null;
    }
    this.updateHUD();
  },

  /* ============ دوربین عمودی ============
     camY = مختصات دنیا (World Space) که لبه‌ی بالای ویوپورت روی آن است.
     هر چیزِ داخل دنیا با ctx.translate(0, -camY) رسم می‌شود؛ HUD بیرون از بوم (DOM) است و ثابت می‌ماند.
     فیزیک، برخورد و منطق بازی هرگز camY را نمی‌خوانند → دوربین روی گیم‌پلی اثری ندارد. */
  setupCameraBounds() {
    const L = this.level;
    /* پایین: کف دنیا (ROWS*TILE) دقیقاً لبه‌ی پایین ویوپورت است، پس دوربین هرگز پایین‌تر از آن نمی‌رود.
       بالا: فضای آسمانِ بالای مرحله؛ مراحل صعودی ارتفاع بیشتری دارند. */
    this.camMaxY = Math.max(0, ROWS * TILE - VIEW_H);
    this.camMinY = this.camMaxY - (L.hasClimb ? 300 : 160);
  },

  updateCamera(snap) {
    const P = this.P;
    if (!P) return;
    const cy = P.y + P.h / 2;
    /* ناحیه‌ی مرده: تا وقتی بازیکن بین ۳۸٪ و ۶۲٪ ارتفاع صفحه است، دوربین تکان نمی‌خورد
       (پرش‌های معمولی صفحه را بالا و پایین نمی‌کنند) */
    const UP = VIEW_H * 0.38, DOWN = VIEW_H * 0.62;
    const rel = cy - this.camTargetY;
    if (rel < UP) this.camTargetY = cy - UP;
    else if (rel > DOWN) this.camTargetY = cy - DOWN;
    this.camTargetY = clamp(this.camTargetY, this.camMinY, this.camMaxY);

    if (snap) {
      this.camY = this.camTargetY;
    } else {
      this.camY = lerp(this.camY, this.camTargetY, 0.13);
      if (Math.abs(this.camY - this.camTargetY) < 0.05) this.camY = this.camTargetY;   // جلوگیری از لرزش ریز
    }
    this.camY = clamp(this.camY, this.camMinY, this.camMaxY);
  },

  /* ============ برخورد کاشی ============ */
  GT(tx, ty) {
    const L = this.level;
    if (tx < 0 || tx >= L.w) return T_GROUND;      // دیوارهای کنار دنیا
    if (ty < 0 || ty >= ROWS) return T_EMPTY;
    return L.grid[ty * L.w + tx];
  },
  solidT(t) { return t === T_GROUND || t === T_BRICK; },

  moveX(e, dx) {
    if (dx === 0) return;
    e.x += dx;
    const dir = dx > 0 ? 1 : -1;
    const edge = dir > 0 ? e.x + e.w : e.x;
    const tx = Math.floor(edge / TILE);
    const ty0 = Math.floor((e.y + 2) / TILE), ty1 = Math.floor((e.y + e.h - 2) / TILE);
    for (let ty = ty0; ty <= ty1; ty++) {
      if (this.solidT(this.GT(tx, ty))) {
        e.x = dir > 0 ? tx * TILE - e.w - 0.01 : (tx + 1) * TILE + 0.01;
        e.vx = 0; return;
      }
    }
  },
  moveY(e, dy) {
    if (dy === 0) return;
    const prevBottom = e.y + e.h;
    e.y += dy;
    const tx0 = Math.floor((e.x + 2) / TILE), tx1 = Math.floor((e.x + e.w - 2) / TILE);
    if (dy > 0) {
      const ty = Math.floor((e.y + e.h) / TILE);
      for (let tx = tx0; tx <= tx1; tx++) {
        const t = this.GT(tx, ty);
        if (this.solidT(t) || (t === T_PLAT && prevBottom <= ty * TILE + 6)) {
          e.y = ty * TILE - e.h - 0.01; e.vy = 0; e.onGround = true; return;
        }
      }
    } else {
      const ty = Math.floor(e.y / TILE);
      for (let tx = tx0; tx <= tx1; tx++) {
        if (this.solidT(this.GT(tx, ty))) {
          e.y = (ty + 1) * TILE + 0.01; e.vy = 0; return;
        }
      }
    }
  },

  /* ============ آیتم‌ها / خطرها ============ */
  tileInteract() {
    const P = this.P;
    const tx0 = Math.floor(P.x / TILE), tx1 = Math.floor((P.x + P.w) / TILE);
    const ty0 = Math.floor(P.y / TILE), ty1 = Math.floor((P.y + P.h) / TILE);
    for (let tx = tx0; tx <= tx1; tx++) {
      for (let ty = ty0; ty <= ty1; ty++) {
        const v = this.GT(tx, ty);
        if (v === T_EMPTY || v === T_GROUND || v === T_BRICK || v === T_PLAT) continue;
        const cx = tx * TILE + TILE / 2, cy = ty * TILE + TILE / 2;
        if (v === T_COIN) {
          this.level.grid[ty * this.level.w + tx] = T_EMPTY;
          this.coinsRun++; Save.addCoins(1);
          AudioSys.sfx('coin'); this.sparkle(cx, cy, '#ffd23e');
          this.float(cx, cy, '+۱', '#ffd23e');
        } else if (v === T_DIAM) {
          this.level.grid[ty * this.level.w + tx] = T_EMPTY;
          this.diamRun++; Save.addDiamonds(1);
          AudioSys.sfx('diamond'); this.sparkle(cx, cy, '#4de3e0');
          this.float(cx, cy, '+۱ 💎', '#4de3e0');
        } else if (v === T_CONE) {
          this.level.grid[ty * this.level.w + tx] = T_EMPTY;
          this.cones = Math.min(this.cones + CONES_PER_PICKUP, 99);
          AudioSys.sfx('cone'); this.sparkle(cx, cy, '#b5814a');
          this.float(cx, cy, '+' + faNum(CONES_PER_PICKUP) + ' 🌲', '#f0b060');
        } else if (v === T_HEART) {
          /* ❤️ قلب اضافه */
          this.level.grid[ty * this.level.w + tx] = T_EMPTY;
          AudioSys.sfx('heart'); this.sparkle(cx, cy, '#ff4d5e');
          if (this.hearts < MAX_HEARTS) {
            this.hearts++;
            this.float(cx, cy - 14, '+۱ ❤️', '#ff8d99');
          } else this.float(cx, cy - 14, 'قلب‌ها پر است!', '#ffb3ba');
        } else if (v === T_SHIELD) {
          /* 🛡️ سپر محافظ */
          this.level.grid[ty * this.level.w + tx] = T_EMPTY;
          this.shield = 1;
          AudioSys.sfx('shield'); this.sparkle(cx, cy, '#3f8cff');
          this.float(cx, cy - 14, '🛡️ سپر فعال شد', '#7db6ff');
        } else if (v === T_CHECK && !this.checkActive) {
          this.checkActive = true;
          /* مرکز ستونِ پرچم — تا محاسبه‌ی ستون هنگام بازگشت اشتباه نشود */
          this.respawnX = tx * TILE + 2;
          AudioSys.sfx('check');
          this.float(cx, cy - 20, '✓ نقطه بازگشت', '#7CFC9A');
          this.sparkle(cx, cy, '#7CFC9A');
        } else if (v === T_SPIKE) {
          if (this.P.invuln <= 0) this.hurt();
        }
      }
    }
  },

  /* ============ دشمنان ============ */
  updateEnemies() {
    for (const e of this.enemies) {
      if (e.dead) { e.deadT--; continue; }
      if (Math.abs(e.x - this.camX) > VIEW_W + 220) continue;   // خارج از دید
      if (e.type === 'flyer') {
        e.a += 0.02 + this.lvl * 0.0009;
        e.x = e.x0 + Math.sin(e.a) * e.range;
        e.y = e.y0 + Math.sin(e.a * 2.3) * 24;
      } else {
        e.t++;
        e.vy = Math.min(e.vy + GRAV, MAXFALL);
        e.onGround = false;
        this.moveY(e, e.vy);
        if (e.onGround) {
          const aheadX = e.dir > 0 ? e.x + e.w + 3 : e.x - 3;
          const atx = Math.floor(aheadX / TILE);
          const footTy = Math.floor((e.y + e.h + 6) / TILE);
          const midTy = Math.floor((e.y + e.h / 2) / TILE);
          const wall = this.solidT(this.GT(atx, midTy));
          const gt = this.GT(atx, footTy);
          const ground = this.solidT(gt) || gt === T_PLAT;
          if (wall || !ground) e.dir *= -1;
          else {
            e.x += e.dir * e.speed;
            if (e.x < e.min) { e.x = e.min; e.dir = 1; }
            if (e.x + e.w > e.max) { e.x = e.max - e.w; e.dir = -1; }
          }
        }
      }
      if (e.deadT < 0) e.deadT = 0;
    }
    /* پاک‌سازی مردگان تمام‌شده */
    this.enemies = this.enemies.filter(e => !e.dead || e.deadT > 0);
  },

  stomp(e) {
    e.dead = true; e.deadT = 20;
    const P = this.P;
    P.vy = Keys.jump ? -JUMPV * 0.85 : -8;
    P.jumping = false;   // جهش له‌کردن دشمن بریده نشود
    AudioSys.sfx('stomp');
    Save.addCoins(2); this.coinsRun += 2;
    this.float(e.x + e.w / 2, e.y, '+۲', '#ffd23e');
    this.poof(e.x + e.w / 2, e.y + e.h / 2, '#d9903f');
  },
  killEnemy(e, byShot) {
    e.dead = true; e.deadT = byShot ? 1 : 20;
    Save.addCoins(2); this.coinsRun += 2;
    this.float(e.x + e.w / 2, e.y, '+۲', '#ffd23e');
    this.poof(e.x + e.w / 2, e.y + e.h / 2, e.type === 'spiky' ? '#8a5fc4' : '#d9903f');
    AudioSys.sfx('stomp');
  },

  hurt() {
    const P = this.P;
    if (P.invuln > 0) return;
    /* زره مرد زرهی: تا ۴ برخورد پشت‌سرهم بی‌آسیب — اگر ۸ ثانیه ضربه نخوری شارژها برمی‌گردند */
    if (Save.data.skin === 'armor') {
      if (this.tick - this.armorLastHit > 480) this.armorHits = 0;
      if (this.armorHits < 4) {
        this.armorHits++;
        this.armorLastHit = this.tick;
        P.invuln = 60;
        AudioSys.sfx('shieldbreak');
        this.poof(P.x + P.w / 2, P.y + P.h / 2, '#c7d0e0');
        this.float(P.x + P.w / 2, P.y - 16,
          this.armorHits < 4 ? 'زره! ' + faNum(4 - this.armorHits) + ' ضربه دیگر' : 'آخرین ضربه زره!',
          '#c7d0e0');
        return;
      }
      this.float(P.x + P.w / 2, P.y - 16, 'زره شکست!', '#ff9d9d');
    }
    if (this.shield > 0) {
      /* سپر اولین ضربه را جذب می‌کند */
      this.shield = 0;
      P.invuln = 90;
      AudioSys.sfx('shieldbreak');
      this.poof(P.x + P.w / 2, P.y + P.h / 2, '#3f8cff');
      this.float(P.x + P.w / 2, P.y - 16, 'سپر شکست! 🛡️', '#7db6ff');
      return;
    }
    if (!CHEAT_INF_HEARTS) this.hearts--;
    AudioSys.sfx('hurt');
    P.invuln = 110;
    P.vy = -6; P.vx = -P.face * 3; P.jumping = false;   // عقب‌زدگی بریده نشود
    this.poof(P.x + P.w / 2, P.y + P.h / 2, '#ff6472');
    if (this.hearts <= 0) { this.hearts = 0; this.gameOver('hearts'); }
  },

  fallPenalty() {
    if (this.shield > 0) {
      /* سپر جان را نجات می‌دهد ولی به نقطه بازگشت برمی‌گردی */
      this.shield = 0;
      AudioSys.sfx('shieldbreak');
    } else {
      if (!CHEAT_INF_HEARTS) this.hearts--;
      AudioSys.sfx('hurt');
      if (this.hearts <= 0) { this.hearts = 0; this.gameOver('hearts'); return; }
    }
    const P = this.P;
    /* بازگشت به نقطه بازگشت/شروع — همیشه روی زمین واقعی، نه داخل دره */
    const L = this.level;
    let rtx = clamp(Math.floor(this.respawnX / TILE), 1, L.w - 2);
    /* اگر ستون نقطه‌ی بازگشت پرتگاه بود، نزدیک‌ترین ستون دارای زمین را پیدا کن */
    if (!(L.top[rtx] > 0)) {
      let best = -1;
      for (let d = 1; d < L.w && best < 0; d++) {
        if (rtx - d >= 0 && L.top[rtx - d] > 0) best = rtx - d;
        else if (rtx + d < L.w && L.top[rtx + d] > 0) best = rtx + d;
      }
      if (best >= 0) rtx = best;
    }
    const gy = L.top[rtx] > 0 ? L.top[rtx] : 14;
    P.x = rtx * TILE + 2;
    P.y = gy * TILE - P.h - 4;
    P.vx = 0; P.vy = 0; P.invuln = 130;
    this.camX = clamp(P.x - VIEW_W * 0.42, 0, L.w * TILE - VIEW_W);
    this.camTargetY = 0; this.updateCamera(true);   // دوربین هم‌زمان با بازیکن به نقطه‌ی بازگشت می‌پرد
    this.float(P.x + 10, P.y - 20, 'مواظب باش!', '#ff9d9d');
  },

  /* ============ موج شیطانی (اسکین قهرمان شیطانی) ============ */
  devilWave() {
    if (this.state !== 'play') return;
    if (Save.data.skin !== 'demon') return;
    const P = this.P;
    if (this.waveLeft <= 0) {
      this.float(P.x + 10, P.y - 20, 'موج شیطانی تمام شد!', '#ff5e8a');
      return;
    }
    this.waveLeft--;
    const cx = P.x + P.w / 2, cy = P.y + P.h / 2;
    const R = TILE * 8;   // شعاع موج: حدود ۸ کاشی (چند متر اطراف)
    this.waveFx = { x: cx, y: cy, r: 12, max: R, life: 42 };
    for (const e of this.enemies) {
      if (e.dead) continue;
      const dx = e.x + e.w / 2 - cx, dy = e.y + e.h / 2 - cy;
      if (Math.hypot(dx, dy) <= R) this.killEnemy(e, false);
    }
    AudioSys.sfx('shieldbreak');
    this.float(cx, P.y - 26, '🌊 موج شیطانی!', '#ff5e8a');
    if (typeof UI !== 'undefined' && UI.updateWaveBtn) UI.updateWaveBtn();
  },

  /* ============ پایان‌ها ============ */
  completeLevel() {
    if (this.state !== 'play') return;
    this.state = 'complete';
    resetKeys();
    AudioSys.sfx('win'); AudioSys.stopMusic();
    Save.completeLevel(this.lvl);
    if (typeof UI !== 'undefined') UI.onLevelComplete();
  },
  gameOver(reason) {
    if (this.state !== 'play') return;
    this.state = 'over';
    resetKeys();
    AudioSys.sfx('lose'); AudioSys.stopMusic();
    if (typeof UI !== 'undefined') UI.onGameOver(reason);
  },

  /* ============ ذرات ============ */
  dust(x, y) {
    for (let i = 0; i < 6; i++)
      this.parts.push({ x: x + rndOff(8), y: y - 3, vx: rndOff(2), vy: -Math.random() * 1.5, g: 0.05, life: 22, max: 22, c: '#ffffff', s: 3, type: 'dust' });
  },
  sparkle(x, y, c) {
    for (let i = 0; i < 10; i++) {
      const a = Math.random() * Math.PI * 2, sp = 1 + Math.random() * 2.4;
      this.parts.push({ x, y, vx: Math.cos(a) * sp, vy: Math.sin(a) * sp - 1, g: 0.08, life: 26, max: 26, c, s: 3, type: 'spark' });
    }
  },
  poof(x, y, c) {
    for (let i = 0; i < 8; i++)
      this.parts.push({ x: x + rndOff(6), y: y + rndOff(6), vx: rndOff(1.6), vy: -Math.random() * 2, g: 0.02, life: 24, max: 24, c, s: 5, type: 'poof' });
  },
  float(x, y, txt, c) { this.texts.push({ x, y, txt, c, life: 55 }); },

  updateParts() {
    for (let i = this.parts.length - 1; i >= 0; i--) {
      const p = this.parts[i];
      p.x += p.vx; p.y += p.vy; p.vy += p.g; p.life--;
      if (p.life <= 0) this.parts.splice(i, 1);
    }
    for (let i = this.texts.length - 1; i >= 0; i--) {
      const t = this.texts[i];
      t.y -= 0.8; t.life--;
      if (t.life <= 0) this.texts.splice(i, 1);
    }
  },
  ambient() {
    const th = this.level.th;
    if (th.snow && this.tick % 6 === 0 && this.parts.filter(p => p.type === 'snow').length < 50) {
      this.parts.push({ x: this.camX + Math.random() * VIEW_W, y: this.camY - 10, vx: rndOff(0.4) - 0.3, vy: 0.7 + Math.random(), g: 0, life: 700, max: 700, c: '#ffffff', s: 2 + Math.random() * 2, type: 'snow' });
    }
    if (th.ember && this.tick % 8 === 0) {
      this.parts.push({ x: this.camX + Math.random() * VIEW_W, y: VIEW_H + this.camY + 10, vx: rndOff(0.5), vy: -0.9 - Math.random() * 1.2, g: -0.004, life: 220, max: 220, c: Math.random() < 0.5 ? '#ff9d1c' : '#ffd23e', s: 2, type: 'ember' });
    }
  },

  /* ============ HUD ============ */
  updateHUD() {
    if (typeof UI !== 'undefined') UI.updateHUD();
  },

  /* ============ رندر ============ */
  render() {
    const ctx = C.ctx, L = this.level;
    if (!L) return;
    const th = L.th, cam = Math.floor(this.camX);

    /* آسمان */
    if (!this._skyGrad) {
      const g = ctx.createLinearGradient(0, 0, 0, VIEW_H);
      g.addColorStop(0, th.skyTop); g.addColorStop(1, th.skyBot);
      this._skyGrad = g;
    }
    ctx.fillStyle = this._skyGrad;
    ctx.fillRect(0, 0, VIEW_W, VIEW_H);

    /* ستاره‌ها و ماه */
    if (th.stars) {
      ctx.fillStyle = '#ffffff';
      for (let i = 0; i < 55; i++) {
        const sx = mod(i * 173 - cam * 0.12, VIEW_W + 40) - 20;
        const sy = mod(i * 97, 290);
        const tw = (this.tick * 0.05 + i) % 6 < 5 ? 1 : 0.4;
        ctx.globalAlpha = 0.5 + 0.5 * tw;
        ctx.fillRect(sx, sy, i % 7 === 0 ? 2 : 1, i % 7 === 0 ? 2 : 1);
      }
      ctx.globalAlpha = 1;
      /* ماه */
      const mx = mod(700 - cam * 0.1, VIEW_W + 300) - 100;
      ctx.fillStyle = '#f4f6ff';
      ctx.beginPath(); ctx.arc(mx, 80, 26, 0, 7); ctx.fill();
      ctx.fillStyle = th.skyTop;
      ctx.beginPath(); ctx.arc(mx + 10, 72, 22, 0, 7); ctx.fill();
    }

    /* تپه‌های پارالاکس — با دوربین عمودی کمی جابه‌جا می‌شوند (پارالاکس عمودی) */
    this.drawHills(ctx, cam, th);

    /* ابرها */
    this.drawClouds(ctx, cam, th);

    /* همه‌چیزِ داخل دنیا با دوربین عمودی جابه‌جا می‌شود */
    const camY = Math.floor(this.camY);
    ctx.save();
    ctx.translate(0, -camY);

    /* کاشی‌ها */
    const tx0 = Math.max(0, Math.floor(cam / TILE) - 1);
    const tx1 = Math.min(L.w - 1, Math.floor((cam + VIEW_W) / TILE) + 1);
    /* فقط ردیف‌های داخل ویوپورت رسم می‌شوند؛ بخش‌های خارج از دید حذف نمی‌شوند و با بازگشت دوربین دوباره دیده می‌شوند */
    const ty0 = Math.max(0, Math.floor(camY / TILE) - 1);
    const ty1 = Math.min(ROWS - 1, Math.floor((camY + VIEW_H) / TILE) + 1);
    for (let tx = tx0; tx <= tx1; tx++) {
      /* تزئین روی سطح زمین */
      if (L.top[tx] > 0 && this.GT(tx, L.top[tx] - 1) === T_EMPTY) this.drawDeco(ctx, tx, th);
      for (let ty = ty0; ty <= ty1; ty++) {
        const v = L.grid[ty * L.w + tx];
        if (v === T_EMPTY) continue;
        const px = tx * TILE - cam, py = ty * TILE;
        switch (v) {
          case T_GROUND: this.drawGround(ctx, px, py, tx, ty, th); break;
          case T_BRICK: this.drawBrick(ctx, px, py, th); break;
          case T_PLAT: this.drawPlat(ctx, px, py, th); break;
          case T_COIN: this.drawCoin(ctx, px, py, tx); break;
          case T_DIAM: this.drawDiamond(ctx, px, py); break;
          case T_CONE: this.drawCone(ctx, px, py); break;
          case T_SPIKE: this.drawSpike(ctx, px, py); break;
          case T_CHECK: this.drawCheck(ctx, px, py); break;
          case T_HEART: this.drawHeartTile(ctx, px, py); break;
          case T_SHIELD: this.drawShieldTile(ctx, px, py); break;
        }
      }
    }

    /* قلعه و پرچم */
    this.drawCastle(ctx, L.castleX - cam, L, th);
    this.drawFlag(ctx, L.flagX - cam, L);

    /* تیرها */
    for (const s of this.shots) {
      ctx.save();
      ctx.translate(s.x - cam + 6, s.y + 6);
      ctx.rotate(s.rot);
      ctx.fillStyle = '#8a5a2b';
      ctx.beginPath(); ctx.arc(0, 0, 6, 0, 7); ctx.fill();
      ctx.strokeStyle = '#5e3a14'; ctx.lineWidth = 1.5;
      ctx.beginPath(); ctx.moveTo(-5, -2); ctx.lineTo(5, -2); ctx.moveTo(-5, 2); ctx.lineTo(5, 2); ctx.stroke();
      ctx.restore();
    }

    /* دشمنان */
    for (const e of this.enemies) {
      const ex = e.x - cam;
      if (ex < -60 || ex > VIEW_W + 60) continue;
      if (e.y + e.h < camY - 60 || e.y > camY + VIEW_H + 60) continue;   // خارج از ویوپورت عمودی
      this.drawEnemy(ctx, e, ex);
    }

    /* بازیکن */
    if (this.P) this.drawPlayer(ctx, this.P, cam);

    /* حلقه موج شیطانی */
    if (this.waveFx) {
      const w = this.waveFx;
      const a = Math.max(0, w.life / 42);
      ctx.lineWidth = 6;
      ctx.strokeStyle = 'rgba(255,94,138,' + (0.85 * a).toFixed(3) + ')';
      ctx.beginPath(); ctx.arc(w.x - cam, w.y, w.r, 0, 7); ctx.stroke();
      ctx.lineWidth = 10;
      ctx.strokeStyle = 'rgba(110,16,40,' + (0.45 * a).toFixed(3) + ')';
      ctx.beginPath(); ctx.arc(w.x - cam, w.y, Math.max(4, w.r * 0.72), 0, 7); ctx.stroke();
    }

    /* ذرات */
    for (const p of this.parts) {
      const a = p.life / p.max;
      ctx.globalAlpha = p.type === 'snow' || p.type === 'ember' ? 0.8 : a;
      ctx.fillStyle = p.c;
      if (p.type === 'poof') { const r = p.s * (2 - a); ctx.beginPath(); ctx.arc(p.x - cam, p.y, r, 0, 7); ctx.fill(); }
      else ctx.fillRect(p.x - cam, p.y, p.s, p.s);
      ctx.globalAlpha = 1;
    }

    /* متن‌های شناور */
    ctx.font = 'bold 15px Vazirmatn, Tahoma, sans-serif';
    ctx.textAlign = 'center';
    for (const t of this.texts) {
      ctx.globalAlpha = Math.min(1, t.life / 25);
      ctx.fillStyle = t.c;
      ctx.fillText(t.txt, t.x - cam, t.y);
      ctx.globalAlpha = 1;
    }
    ctx.textAlign = 'start';

    ctx.restore();

    /* تاریکی ساده گوشه‌ها برای تم شب/آتشفشان */
    if (th.stars || th.ember) {
      const g = ctx.createRadialGradient(VIEW_W / 2, VIEW_H / 2, VIEW_H * 0.45, VIEW_W / 2, VIEW_H / 2, VIEW_H);
      g.addColorStop(0, 'rgba(0,0,0,0)'); g.addColorStop(1, 'rgba(0,0,0,0.35)');
      ctx.fillStyle = g; ctx.fillRect(0, 0, VIEW_W, VIEW_H);
    }
  },

  hash1(n) { const s = Math.sin(n * 127.1 + this.lvl * 311.7) * 43758.5453; return s - Math.floor(s); },

  drawHills(ctx, cam, th) {
    const draw = (par, col, base, pseed) => {
      const P = 460;
      const k0 = Math.floor((cam * par - 240) / P), k1 = Math.floor((cam * par + VIEW_W + 240) / P);
      ctx.fillStyle = col;
      for (let k = k0; k <= k1; k++) {
        const h = this.hash1(k * 7.3 + pseed);
        const r = 55 + h * 95;
        const hx = k * P + h * 180 - cam * par;
        ctx.beginPath();
        ctx.arc(hx, base + r * 0.55, r, Math.PI, 0);
        ctx.fill();
      }
    };
    draw(0.25, th.hill2, VIEW_H - 120 - Math.floor(this.camY) * 0.3, 2);
    draw(0.45, th.hill, VIEW_H - 60 - Math.floor(this.camY) * 0.5, 5);
  },

  drawClouds(ctx, cam, th) {
    const P = 380, par = 0.2;
    const k0 = Math.floor((cam * par - 200) / P), k1 = Math.floor((cam * par + VIEW_W + 200) / P);
    ctx.fillStyle = th.cloud;
    ctx.globalAlpha = 0.9;
    for (let k = k0; k <= k1; k++) {
      const h = this.hash1(k * 3.7 + 9);
      const w = 60 + h * 70, ht = 16 + h * 12;
      const cx = k * P + h * 140 - cam * par;
      const cy = 34 + this.hash1(k * 9.1) * 120 - Math.floor(this.camY) * 0.2;
      ctx.beginPath();
      ctx.arc(cx, cy, ht, 0, 7);
      ctx.arc(cx + w * 0.45, cy - ht * 0.35, ht * 0.85, 0, 7);
      ctx.arc(cx + w * 0.85, cy, ht * 0.8, 0, 7);
      ctx.fill();
    }
    ctx.globalAlpha = 1;
  },

  drawDeco(ctx, tx, th) {
    const L = this.level;
    const h = this.hash1(tx * 13.7);
    if (h > 0.24) return;
    const px = tx * TILE - Math.floor(this.camX);
    const py = L.top[tx] * TILE;
    const kind = th.deco;
    if (kind === 'bush') {
      ctx.fillStyle = '#2b7a35';
      ctx.beginPath(); ctx.arc(px + 16, py - 8, 13, Math.PI, 0); ctx.arc(px + 4, py - 4, 9, Math.PI, 0); ctx.arc(px + 27, py - 4, 9, Math.PI, 0); ctx.fill();
    } else if (kind === 'cactus') {
      ctx.fillStyle = '#2f8a44';
      ctx.fillRect(px + 12, py - 30, 9, 30);
      ctx.fillRect(px + 4, py - 22, 8, 5); ctx.fillRect(px + 4, py - 22, 5, 12);
      ctx.fillRect(px + 21, py - 26, 8, 5); ctx.fillRect(px + 24, py - 26, 5, 9);
    } else if (kind === 'pine') {
      ctx.fillStyle = '#5e3a14'; ctx.fillRect(px + 13, py - 10, 6, 10);
      ctx.fillStyle = '#1f6e40';
      for (let i = 0; i < 3; i++) {
        const w = 26 - i * 6, yy = py - 10 - i * 12;
        ctx.beginPath(); ctx.moveTo(px + 16 - w / 2, yy); ctx.lineTo(px + 16 + w / 2, yy); ctx.lineTo(px + 16, yy - 15); ctx.fill();
      }
      ctx.fillStyle = 'rgba(255,255,255,0.75)';
      ctx.beginPath(); ctx.moveTo(px + 16, py - 46); ctx.lineTo(px + 21, py - 38); ctx.lineTo(px + 11, py - 38); ctx.fill();
    } else if (kind === 'rock') {
      ctx.fillStyle = '#552a1e';
      ctx.beginPath(); ctx.moveTo(px + 2, py); ctx.lineTo(px + 9, py - 14); ctx.lineTo(px + 22, py - 17); ctx.lineTo(px + 30, py); ctx.fill();
      ctx.fillStyle = '#ff7b1c';
      ctx.fillRect(px + 12, py - 8, 3, 3); ctx.fillRect(px + 18, py - 5, 2, 2);
    } else if (kind === 'torch') {
      ctx.fillStyle = '#3a3a5a'; ctx.fillRect(px + 14, py - 26, 4, 26);
      const fl = Math.sin(this.tick * 0.3 + tx) * 2;
      /* نور مشعل */
      const g = ctx.createRadialGradient(px + 16, py - 30, 4, px + 16, py - 30, 70);
      g.addColorStop(0, 'rgba(255,180,60,0.22)'); g.addColorStop(1, 'rgba(255,180,60,0)');
      ctx.fillStyle = g; ctx.beginPath(); ctx.arc(px + 16, py - 30, 70, 0, 7); ctx.fill();
      ctx.fillStyle = '#ff9d1c';
      ctx.beginPath(); ctx.arc(px + 16, py - 29 + fl * 0.4, 5, 0, 7); ctx.fill();
      ctx.fillStyle = '#ffd23e';
      ctx.beginPath(); ctx.arc(px + 16, py - 30 + fl * 0.4, 2.6, 0, 7); ctx.fill();
    }
  },

  drawGround(ctx, px, py, tx, ty, th) {
    const above = this.GT(tx, ty - 1);
    ctx.fillStyle = th.gBody;
    ctx.fillRect(px, py, TILE, TILE);
    /* بافت خاک */
    ctx.fillStyle = th.gDark;
    const h = this.hash1(tx * 31 + ty * 7);
    ctx.fillRect(px + 5 + h * 14, py + 8 + h * 12, 4, 4);
    ctx.fillRect(px + 20 - h * 10, py + 20, 3, 3);
    if (above !== T_GROUND) {
      ctx.fillStyle = th.gTop;
      ctx.fillRect(px, py, TILE, 9);
      ctx.fillStyle = 'rgba(255,255,255,0.22)';
      ctx.fillRect(px, py, TILE, 3);
    }
  },
  drawBrick(ctx, px, py, th) {
    ctx.fillStyle = th.brick;
    ctx.fillRect(px, py, TILE, TILE);
    ctx.strokeStyle = th.brickDark; ctx.lineWidth = 2;
    ctx.strokeRect(px + 1, py + 1, TILE - 2, TILE - 2);
    ctx.beginPath();
    ctx.moveTo(px, py + TILE / 2); ctx.lineTo(px + TILE, py + TILE / 2);
    ctx.moveTo(px + TILE / 2, py); ctx.lineTo(px + TILE / 2, py + TILE / 2);
    ctx.moveTo(px + TILE / 4, py + TILE / 2); ctx.lineTo(px + TILE / 4, py + TILE);
    ctx.moveTo(px + TILE * 3 / 4, py + TILE / 2); ctx.lineTo(px + TILE * 3 / 4, py + TILE);
    ctx.stroke();
  },
  drawPlat(ctx, px, py, th) {
    ctx.fillStyle = th.plat;
    ctx.fillRect(px, py, TILE, 10);
    ctx.fillStyle = 'rgba(255,255,255,0.25)';
    ctx.fillRect(px, py, TILE, 3);
    ctx.fillStyle = th.platLeg;
    ctx.fillRect(px + 4, py + 10, 5, 4);
    ctx.fillRect(px + TILE - 9, py + 10, 5, 4);
  },
  drawCoin(ctx, px, py, tx) {
    const w = 6 + Math.abs(Math.sin(this.tick * 0.07 + tx * 0.9)) * 16;
    const cx = px + TILE / 2, cy = py + TILE / 2;
    ctx.fillStyle = '#ffd23e';
    ctx.beginPath(); ctx.ellipse(cx, cy, w / 2, 11, 0, 0, 7); ctx.fill();
    ctx.fillStyle = '#ff9d1c';
    ctx.beginPath(); ctx.ellipse(cx, cy, w / 4, 7, 0, 0, 7); ctx.fill();
  },
  drawDiamond(ctx, px, py) {
    const cx = px + TILE / 2, cy = py + TILE / 2;
    const bob = Math.sin(this.tick * 0.06 + px) * 3;
    ctx.fillStyle = '#4de3e0';
    ctx.beginPath();
    ctx.moveTo(cx, cy - 12 + bob); ctx.lineTo(cx + 10, cy - 2 + bob);
    ctx.lineTo(cx, cy + 12 + bob); ctx.lineTo(cx - 10, cy - 2 + bob);
    ctx.closePath(); ctx.fill();
    ctx.fillStyle = 'rgba(255,255,255,0.65)';
    ctx.beginPath(); ctx.moveTo(cx, cy - 12 + bob); ctx.lineTo(cx + 10, cy - 2 + bob); ctx.lineTo(cx, cy - 1 + bob); ctx.closePath(); ctx.fill();
  },
  drawCone(ctx, px, py) {
    const cx = px + TILE / 2, cy = py + TILE / 2;
    const bob = Math.sin(this.tick * 0.08 + px) * 3;
    ctx.fillStyle = '#2f8a44';
    ctx.beginPath(); ctx.ellipse(cx, cy - 13 + bob, 4, 7, 0.4, 0, 7); ctx.fill();
    ctx.fillStyle = '#8a5a2b';
    ctx.beginPath(); ctx.ellipse(cx, cy + bob, 9, 12, 0, 0, 7); ctx.fill();
    ctx.strokeStyle = '#5e3a14'; ctx.lineWidth = 1.5;
    for (let i = -1; i <= 1; i++) {
      ctx.beginPath(); ctx.moveTo(cx - 8, cy + i * 6 + bob); ctx.lineTo(cx + 8, cy + i * 6 + bob); ctx.stroke();
    }
    ctx.beginPath(); ctx.moveTo(cx - 5, cy - 9 + bob); ctx.lineTo(cx + 5, cy + 9 + bob); ctx.stroke();
  },
  drawSpike(ctx, px, py) {
    ctx.fillStyle = '#c8ccd8';
    for (let i = 0; i < 3; i++) {
      ctx.beginPath();
      ctx.moveTo(px + i * 11, py + TILE);
      ctx.lineTo(px + i * 11 + 5.5, py + 6);
      ctx.lineTo(px + i * 11 + 11, py + TILE);
      ctx.fill();
    }
    ctx.fillStyle = '#8a8fa0';
    ctx.fillRect(px, py + TILE - 5, TILE, 5);
  },
  drawCheck(ctx, px, py) {
    const on = this.checkActive;
    ctx.fillStyle = '#6a6f80';
    ctx.fillRect(px + 14, py - TILE * 2, 4, TILE * 3);
    ctx.fillStyle = on ? '#39d353' : '#8a8fa0';
    const wave = Math.sin(this.tick * 0.15) * 2;
    ctx.beginPath();
    ctx.moveTo(px + 18, py - TILE * 2);
    ctx.lineTo(px + 40 + wave, py - TILE * 2 + 7);
    ctx.lineTo(px + 18, py - TILE * 2 + 14);
    ctx.fill();
  },
  drawHeartTile(ctx, px, py) {
    const cx = px + TILE / 2, y = py + TILE / 2 + Math.sin(this.tick * 0.07 + px) * 3;
    ctx.fillStyle = '#ff4d5e';
    ctx.beginPath();
    ctx.arc(cx - 5, y - 4, 5.5, 0, 7);
    ctx.arc(cx + 5, y - 4, 5.5, 0, 7);
    ctx.fill();
    ctx.beginPath();
    ctx.moveTo(cx - 10, y - 2);
    ctx.lineTo(cx, y + 11);
    ctx.lineTo(cx + 10, y - 2);
    ctx.closePath(); ctx.fill();
    ctx.fillStyle = 'rgba(255,255,255,0.7)';
    ctx.fillRect(cx - 7, y - 7, 3, 3);
  },
  drawShieldTile(ctx, px, py) {
    const cx = px + TILE / 2, y = py + TILE / 2 + Math.sin(this.tick * 0.07 + px) * 3;
    ctx.fillStyle = '#3f8cff';
    ctx.beginPath();
    ctx.moveTo(cx, y - 12);
    ctx.lineTo(cx + 9, y - 8); ctx.lineTo(cx + 9, y + 2);
    ctx.quadraticCurveTo(cx + 9, y + 9, cx, y + 12);
    ctx.quadraticCurveTo(cx - 9, y + 9, cx - 9, y + 2);
    ctx.lineTo(cx - 9, y - 8);
    ctx.closePath(); ctx.fill();
    ctx.fillStyle = '#9cc4ff';
    ctx.beginPath();
    ctx.moveTo(cx, y - 9);
    ctx.lineTo(cx + 6, y - 6); ctx.lineTo(cx + 6, y + 1);
    ctx.quadraticCurveTo(cx + 6, y + 6, cx, y + 8);
    ctx.quadraticCurveTo(cx - 6, y + 6, cx - 6, y + 1);
    ctx.lineTo(cx - 6, y - 6);
    ctx.closePath(); ctx.fill();
    ctx.fillStyle = '#ffd23e';
    ctx.fillRect(cx - 1.5, y - 5, 3, 6);
    ctx.fillRect(cx - 3, y - 1, 6, 3);
    ctx.fillRect(cx - 1.5, y + 2, 3, 4);
  },
  drawFlag(ctx, px, L) {
    if (px < -80 || px > VIEW_W + 80) return;
    const gy = L.top[L.w - 8] > 0 ? L.top[L.w - 8] : 14;
    const baseY = gy * TILE;
    ctx.fillStyle = '#c8ccd8';
    ctx.fillRect(px + 14, baseY - 190, 5, 190);
    ctx.fillStyle = '#ffd23e';
    ctx.beginPath(); ctx.arc(px + 16.5, baseY - 194, 6, 0, 7); ctx.fill();
    const wave = Math.sin(this.tick * 0.12) * 5;
    ctx.fillStyle = '#ff4d5e';
    ctx.beginPath();
    ctx.moveTo(px + 19, baseY - 186);
    ctx.lineTo(px + 62 + wave, baseY - 172);
    ctx.lineTo(px + 19, baseY - 156);
    ctx.fill();
    ctx.fillStyle = '#fff';
    ctx.font = 'bold 13px Tahoma';
    ctx.fillText('★', px + 28, baseY - 166);
  },
  drawCastle(ctx, px, L, th) {
    if (px < -200 || px > VIEW_W + 200) return;
    const gy = L.top[L.w - 4] > 0 ? L.top[L.w - 4] : 14;
    const baseY = gy * TILE;
    const w = 130, h = 110, x = px, y = baseY - h;
    ctx.fillStyle = th.brick;
    ctx.fillRect(x, y, w, h);
    ctx.fillStyle = th.brickDark;
    for (let i = 0; i < 5; i++) ctx.fillRect(x + i * 28, y - 14, 18, 14);
    ctx.fillRect(x + 12, y + 30, 20, 20);
    ctx.fillRect(x + w - 32, y + 30, 20, 20);
    /* در */
    ctx.fillStyle = '#241511';
    ctx.beginPath();
    ctx.moveTo(x + w / 2 - 18, baseY);
    ctx.lineTo(x + w / 2 - 18, baseY - 34);
    ctx.arc(x + w / 2, baseY - 34, 18, Math.PI, 0);
    ctx.lineTo(x + w / 2 + 18, baseY);
    ctx.fill();
  },

  /* ---------- دشمن‌کشی ---------- */
  drawEnemy(ctx, e, ex) {
    const ey = e.y;
    if (e.type === 'walker') {
      const sq = e.dead ? Math.max(0.3, e.deadT / 20) : 1;
      ctx.save();
      ctx.translate(ex + e.w / 2, ey + e.h);
      ctx.scale(1, sq);
      ctx.fillStyle = '#a3552a';
      ctx.beginPath(); ctx.ellipse(0, -12, 13, 12, 0, Math.PI, 0); ctx.fill();
      ctx.fillRect(-13, -12, 26, 8);
      /* پاها */
      const st = Math.sin(e.t * 0.25) * 3;
      ctx.fillStyle = '#5e2c10';
      ctx.fillRect(-11 + st, -5, 8, 5);
      ctx.fillRect(3 - st, -5, 8, 5);
      if (!e.dead) {
        /* چشم‌ها */
        ctx.fillStyle = '#fff';
        ctx.fillRect(-8, -16, 6, 7); ctx.fillRect(2, -16, 6, 7);
        ctx.fillStyle = '#1a1a1a';
        const look = e.dir * 1.5;
        ctx.fillRect(-6 + look, -14, 3, 4); ctx.fillRect(4 + look, -14, 3, 4);
        ctx.fillStyle = '#5e2c10';
        ctx.fillRect(-9, -20, 8, 3); ctx.fillRect(2, -19, 8, 3);
      }
      ctx.restore();
    } else if (e.type === 'spiky') {
      ctx.save();
      ctx.translate(ex + e.w / 2, ey + e.h / 2);
      if (e.dead) ctx.scale(1, 0.35);
      /* خارها */
      ctx.fillStyle = '#e8ecf4';
      for (let i = 0; i < 5; i++) {
        const a = Math.PI + i * (Math.PI / 4);
        const sx = Math.cos(a) * 12, sy = Math.sin(a) * 12;
        ctx.beginPath(); ctx.moveTo(sx - 3, sy + 2); ctx.lineTo(sx + Math.cos(a) * 8, sy + Math.sin(a) * 8); ctx.lineTo(sx + 3, sy + 2); ctx.fill();
      }
      ctx.fillStyle = '#6b4a9e';
      ctx.beginPath(); ctx.arc(0, 2, 11, 0, 7); ctx.fill();
      ctx.fillStyle = '#ff4d5e';
      ctx.fillRect(-6 + e.dir * 1.5, -1, 3.5, 3.5); ctx.fillRect(2 + e.dir * 1.5, -1, 3.5, 3.5);
      ctx.restore();
    } else { /* flyer */
      ctx.save();
      ctx.translate(ex + e.w / 2, ey + e.h / 2);
      const flap = Math.sin(e.a * 9) * 8;
      ctx.fillStyle = '#3b2f63';
      /* بال‌ها */
      ctx.beginPath(); ctx.moveTo(-4, 0); ctx.quadraticCurveTo(-16, -6 - flap, -22, 2 - flap); ctx.quadraticCurveTo(-14, 4, -4, 5); ctx.fill();
      ctx.beginPath(); ctx.moveTo(4, 0); ctx.quadraticCurveTo(16, -6 - flap, 22, 2 - flap); ctx.quadraticCurveTo(14, 4, 4, 5); ctx.fill();
      /* بدن */
      ctx.beginPath(); ctx.ellipse(0, 0, 8, 9, 0, 0, 7); ctx.fill();
      ctx.fillStyle = '#ffd23e';
      ctx.fillRect(-4, -3, 3, 3); ctx.fillRect(2, -3, 3, 3);
      ctx.fillStyle = '#3b2f63';
      ctx.beginPath(); ctx.moveTo(0, 5); ctx.lineTo(-2, 9); ctx.lineTo(2, 9); ctx.fill();
      ctx.restore();
    }
  },

  /* ---------- بازیکن ---------- */
  drawPlayer(ctx, P, cam) {
    if (P.invuln > 0 && Math.floor(this.tick / 4) % 2 === 0) return;
    const skin = skinById(Save.data.skin);
    drawChar(ctx, P.x - cam, P.y, P.w, P.h, skin, {
      face: P.face,
      walk: P.onGround && Math.abs(P.vx) > 0.4 ? Math.floor(P.anim / 22) % 4 : (P.onGround ? -1 : -2),
      shootPose: P.shootPose > 0
    });
    /* حباب سپر محافظ دور بازیکن */
    if (this.shield > 0) {
      const pu = Math.sin(this.tick * 0.12);
      const cx = P.x - cam + P.w / 2, cy = P.y + P.h / 2;
      ctx.strokeStyle = 'rgba(80,170,255,' + (0.5 + 0.2 * pu).toFixed(3) + ')';
      ctx.lineWidth = 2.5;
      ctx.beginPath(); ctx.arc(cx, cy, 26 + pu * 2, 0, 7); ctx.stroke();
      ctx.strokeStyle = 'rgba(160,215,255,' + (0.35 + 0.2 * pu).toFixed(3) + ')';
      ctx.lineWidth = 1.5;
      const rot = this.tick * 0.05;
      for (let i = 0; i < 3; i++) {
        ctx.beginPath(); ctx.arc(cx, cy, 30, rot + i * 2.1, rot + i * 2.1 + 1.2); ctx.stroke();
      }
    }
  }
};

/* ---------- رسم کاراکتر (برای فروشگاه هم استفاده می‌شود) ---------- */
function drawChar(ctx, x, y, w, h, skin, opt) {
  const pal = skin.pal;
  const face = opt.face || 1;
  const walk = opt.walk === undefined ? -1 : opt.walk; // -1 ایست، -2 پرش، 0..3 راه‌رفتن
  ctx.save();
  ctx.translate(x + w / 2, y);
  ctx.scale(face, 1);
  ctx.translate(-w / 2, 0);

  const legOff = walk >= 0 ? [0, 2, 0, -2][walk] : 0;
  const jumping = walk === -2;

  /* پاها */
  ctx.fillStyle = pal.shoe;
  if (jumping) {
    ctx.fillRect(3, h - 9, 7, 6); ctx.fillRect(12, h - 11, 7, 6);
  } else {
    ctx.fillRect(3 + legOff, h - 8, 7, 8 - Math.abs(legOff) * 0.5);
    ctx.fillRect(12 - legOff, h - 8, 7, 8 - Math.abs(legOff) * 0.5);
  }

  /* پاچه شلوار */
  ctx.fillStyle = pal.overall;
  ctx.fillRect(3, h - 14, 7, 6);
  ctx.fillRect(12, h - 14, 7, 6);

  /* تنه (پیراهن) */
  ctx.fillRect(2, h - 24, w - 4, 10);

  /* بند اورال */
  ctx.fillStyle = pal.overall;
  ctx.fillRect(4, h - 25, 3, 6);
  ctx.fillRect(w - 7, h - 25, 3, 6);
  ctx.fillRect(4, h - 19, w - 8, 3);

  /* بازوها */
  ctx.fillStyle = pal.shirt;
  if (jumping) {
    ctx.fillRect(-1, h - 30, 4, 9);
    ctx.fillRect(w - 3, h - 30, 4, 9);
  } else if (opt.shootPose) {
    ctx.fillRect(w - 2, h - 26, 8, 4);
    ctx.fillRect(-1, h - 22, 4, 8);
  } else {
    ctx.fillRect(-1, h - 23, 4, 8);
    ctx.fillRect(w - 3, h - 23, 4, 8);
  }

  /* سر */
  ctx.fillStyle = pal.skin;
  ctx.fillRect(4, h - 36, w - 8, 12);

  /* چشم */
  ctx.fillStyle = '#1a1a1a';
  ctx.fillRect(12, h - 33, 2.5, 4);

  /* کلاه / نقاب */
  if (skin.id === 'ninja') {
    ctx.fillStyle = pal.cap;
    ctx.fillRect(3, h - 36, w - 6, 7);
    ctx.fillStyle = pal.acc;
    ctx.fillRect(4, h - 31, w - 8, 3);
  } else if (skin.id === 'armor') {
    /* کلاه‌خود فولادی مرد زرهی */
    ctx.fillStyle = pal.cap;
    ctx.fillRect(3, h - 37, w - 6, 8);
    ctx.fillStyle = '#2a3140';
    ctx.fillRect(4, h - 33, w - 8, 2);          // شکاف نقاب
    ctx.fillStyle = pal.acc;
    ctx.fillRect(5, h - 37, w - 10, 2);         // براقی روی کلاه‌خود
    /* شانه‌پوش‌ها */
    ctx.fillStyle = pal.cap;
    ctx.fillRect(1, h - 26, 5, 9);
    ctx.fillRect(w - 6, h - 26, 5, 9);
    ctx.fillStyle = pal.acc;
    ctx.fillRect(1, h - 26, 5, 2);
    ctx.fillRect(w - 6, h - 26, 5, 2);
  } else if (skin.id === 'astro') {
    ctx.fillStyle = 'rgba(140,220,255,0.45)';
    ctx.beginPath(); ctx.arc(w / 2, h - 29, 11, 0, 7); ctx.fill();
    ctx.strokeStyle = '#e2e8f0'; ctx.lineWidth = 2;
    ctx.beginPath(); ctx.arc(w / 2, h - 29, 11, 0, 7); ctx.stroke();
    ctx.fillStyle = 'rgba(255,255,255,0.75)';
    ctx.fillRect(w / 2 - 6, h - 37, 5, 6);
  } else {
    ctx.fillStyle = pal.cap;
    ctx.fillRect(2, h - 38, w - 4, 6);
    ctx.fillRect(10, h - 34, 10, 3);  // لبه کلاه
    if (skin.id === 'gold') {
      /* تاج */
      ctx.fillStyle = '#fff7cc';
      ctx.beginPath();
      ctx.moveTo(6, h - 38); ctx.lineTo(8, h - 44); ctx.lineTo(11, h - 40);
      ctx.lineTo(w / 2, h - 46); ctx.lineTo(w - 11, h - 40); ctx.lineTo(w - 8, h - 44); ctx.lineTo(w - 6, h - 38);
      ctx.fill();
    }
  }

  /* جواهر سینه الماس‌بازی */
  if (skin.id === 'gem') {
    ctx.fillStyle = '#ffffff';
    ctx.beginPath();
    ctx.moveTo(w / 2, h - 24); ctx.lineTo(w / 2 + 4, h - 20); ctx.lineTo(w / 2, h - 16); ctx.lineTo(w / 2 - 4, h - 20);
    ctx.fill();
  }

  ctx.restore();
}

/* ---------- ابزار کوچک ---------- */
function rectHit(a, b) {
  return a.x < b.x + b.w && a.x + a.w > b.x && a.y < b.y + b.h && a.y + a.h > b.y;
}
function rndOff(m) { return (Math.random() - 0.5) * 2 * m; }
function mod(a, n) { return ((a % n) + n) % n; }

/* ---------- کنترل‌کننده حلقه ---------- */
const C = {
  canvas: null, ctx: null, raf: 0, last: 0, acc: 0,
  init() {
    this.canvas = document.getElementById('game');
    this.ctx = this.canvas.getContext('2d');
    this.ctx.imageSmoothingEnabled = false;
    const loop = (t) => {
      this.raf = requestAnimationFrame(loop);
      if (!this.last) this.last = t;
      let dt = t - this.last; this.last = t;
      if (dt > 100) dt = 100;
      this.acc += dt;
      while (this.acc >= 16.666) {
        if (Game.state === 'play') Game.step();
        this.acc -= 16.666;
      }
      if (Game.state !== 'menu' && Game.level) Game.render();
    };
    this.raf = requestAnimationFrame(loop);
  }
};